# ABIR Education (আবীর এডুকেশন)

**ABIR Education** is a publicly distributable Android educational platform for **Class 1 to Class 12** students, built with **Kotlin, Jetpack Compose, Material 3, MVVM, Room, and Firebase** (Default language: **Bengali / বাংলা**, with runtime **English** switch).

---

## Key Security & Public Access Architecture

1. **Open Student Registration (No Admin Approval Needed)**:
   - Any student can install the app and sign in directly using their own **Google account** via Firebase Authentication + Jetpack Credential Manager.
   - Signing in automatically creates the student's profile in `users/{uid}` with student-only permissions.
2. **Strict Single-Owner Admin Protection**:
   - Only the verified owner Google email (`smnazrul648@gmail.com`) can initialize `/admins/{uid}` and manage classes, subjects, courses, chapters, lessons, PDFs, exams, questions, announcements, results, and student accounts.
   - Enforced exclusively on the backend by `firestore.rules` and `storage.rules` (`request.auth.token.email_verified == true && request.auth.token.email == 'smnazrul648@gmail.com'`).
3. **Privacy & Content Isolation**:
   - Published courses, lessons, chapters, subjects, classes, announcements, and published exams/questions are readable by all signed-in students.
   - Student PII (`users/{uid}`) and exam attempts (`exam_attempts/{attemptId}`) are strictly private to the owning student and the verified owner admin.
   - Leaderboard entries show only non-PII display name/score/time and honor each student's `leaderboardOptIn` privacy toggle.

---

## পাবলিক ডিস্ট্রিবিউশন ও Google Play Store ডিপ্লয়মেন্ট নির্দেশিকা (বাংলা)

### ধাপ ১: Release Keystore তৈরি করা (`my-upload-key.jks`)
Play Store এবং রিলিজ APK-এর জন্য নিজস্ব একটি Upload Keystore তৈরি করুন (কখনও GitHub বা পাবলিক জায়গায় পাসওয়ার্ড রাখবেন না):

```bash
keytool -genkeypair -v -keystore my-upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
```

### ধাপ ২: Release ও Play App Signing SHA-1 / SHA-256 যুক্ত করা (গুরুত্বপূর্ণ)
পাবলিক ইউজারদের ফোনে **Google Sign-In** কাজ করার জন্য আপনার Release Keystore এবং Google Play App Signing-এর **SHA-1 ও SHA-256** ফিঙ্গারপ্রিন্ট Firebase Console-এ যুক্ত করতে হবে:

1. নিজের Release Keystore থেকে ফিঙ্গারপ্রিন্ট বের করুন:
   ```bash
   keytool -list -v -keystore my-upload-key.jks -alias upload
   ```
2. [Firebase Console](https://console.firebase.google.com/)-এ `gen-lang-client-0793812282` প্রজেক্ট খুলুন → **Project Settings → Your apps (`com.abir.education`) → Add fingerprint** থেকে Release SHA-1 ও SHA-256 যোগ করুন।
3. **Google Play Console**-এ অ্যাপ আপলোড করার পর **Release → Setup → App signing** থেকে **App signing key certificate**-এর SHA-1 ও SHA-256 কপি করেও Firebase-এ যোগ করুন এবং আপডেট করা `google-services.json` ডাউনলোড করে `app/google-services.json`-এ বসান।

### ধাপ ৩: Firebase Console-এ Storage ও Push Notifications চালু করা
Firebase Authentication (Google Sign-In) এবং Cloud Firestore + Firestore Rules ইতিমধ্যে প্রজেক্টে ডিপ্লয় করা আছে।
1. **Firebase Storage (PDF নোট আপলোডের জন্য)**: Firebase Console → **Build → Storage → Get started** দিয়ে বাকেট (`gen-lang-client-0793812282.firebasestorage.app`) চালু করুন এবং `storage.rules` প্রকাশ করুন (`firebase deploy --only storage`)।
2. **Push Notifications (FCM)**: Firebase Console → **Engage → Messaging** থেকে শিক্ষার্থীদের কাছে নোটিফিকেশন পাঠাতে পারবেন।

### ধাপ ৪: Signed Release APK ও Google Play AAB তৈরি করা
এনভায়রনমেন্ট ভ্যারিয়েবল সেট করে Gradle চালান (অথবা AI Studio-র মেনু থেকে সরাসরি APK/AAB এক্সপোর্ট করুন):

```bash
export KEYSTORE_PATH="$(pwd)/my-upload-key.jks"
export STORE_PASSWORD="your_store_password"
export KEY_PASSWORD="your_key_password"

# Signed Release APK (সরাসরি ইনস্টলের জন্য)
gradle :app:assembleRelease
# Output: app/build/outputs/apk/release/app-release.apk

# Signed Android App Bundle (Google Play Store-এ আপলোডের জন্য)
gradle :app:bundleRelease
# Output: app/build/outputs/bundle/release/app-release.aab
```

### ধাপ ৫: প্রথমবার অ্যাডমিন প্যানেল চালু করা
1. অ্যাপ ইনস্টল করে `smnazrul648@gmail.com` দিয়ে Google Sign-In করুন।
2. **Profile → অ্যাডমিন কন্ট্রোল প্যানেল**-এ গিয়ে **অ্যাডমিন অ্যাকাউন্ট ইনিশিয়ালাইজ করুন** ট্যাপ করুন।
3. **শ্রেণি ১–১২ সিড** করে আপনার প্রথম কোর্স, লেসন ও MCQ পরীক্ষা প্রকাশ করুন।

---

## Verification & Testing Commands

```bash
# Unit & Robolectric tests
gradle :app:testDebugUnitTest

# Debug APK build
gradle :app:assembleDebug

# Firestore Security Rules Emulator Tests
FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js
```
