# ProGuard / R8 rules for ABIR Education release APK and Google Play AAB builds

# Preserve line numbers and source file names for crash diagnostics
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Preserve annotations and @Keep Firestore data models
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class androidx.annotation.Keep
-keep @androidx.annotation.Keep class * { *; }
-keepclassmembers class com.example.model.** { *; }

# Keep Jetpack Credential Manager & Google Identity Services
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }

# Keep Firebase Messaging Service
-keep class com.example.notifications.AbirMessagingService { *; }
