package com.example

import com.example.config.AdminConfig
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.model.AnnouncementPriority
import com.example.model.LessonType
import com.example.util.BanglaDateUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ExampleUnitTest {

    @Test
    fun banglaDigitsConversion_formatsCorrectly() {
        assertEquals("১২৩৪৫৬৭৮৯০", BanglaDateUtils.toBanglaDigits("1234567890"))
        assertEquals("শ্রেণি ১০", BanglaDateUtils.formatClassLabel(10, isBangla = true))
        assertEquals("Class 10", BanglaDateUtils.formatClassLabel(10, isBangla = false))
    }

    @Test
    fun banglaTimerAndNumbers_formatCorrectly() {
        assertEquals("০৫:০৯", BanglaDateUtils.formatTimer(309, isBangla = true))
        assertEquals("05:09", BanglaDateUtils.formatTimer(309, isBangla = false))
        assertEquals("১২.৫০", BanglaDateUtils.formatNumber(12.5, isBangla = true))
        assertEquals("10", BanglaDateUtils.formatNumber(10.0, isBangla = false))
    }

    @Test
    fun banglaReadableDateTime_containsBanglaMonthAndPeriod() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.APRIL, 16, 9, 30, 0)
        }
        val formatted = BanglaDateUtils.formatReadableDateTime(cal.time, isBangla = true)
        assertTrue(formatted.contains("এপ্রিল"))
        assertTrue(formatted.contains("সকাল"))
        assertTrue(formatted.contains("১৬"))
    }

    @Test
    fun adminConfigAndLocalization_defaultsToBangla() {
        assertEquals("smnazrul648@gmail.com", AdminConfig.OWNER_ADMIN_EMAIL)
        assertEquals(AppLanguage.BN, AppLanguage.fromCode(null))
        assertEquals(AppLanguage.EN, AppLanguage.fromCode("en"))
        assertFalse(stringsFor(AppLanguage.BN).appName.isBlank())
        assertEquals("ABIR Education", stringsFor(AppLanguage.EN).appName)
    }

    @Test
    fun modelEnums_parseSafely() {
        assertEquals(LessonType.PDF, LessonType.safeFrom("pdf"))
        assertEquals(LessonType.TEXT, LessonType.safeFrom("unknown"))
        assertEquals(AnnouncementPriority.IMPORTANT, AnnouncementPriority.safeFrom("IMPORTANT"))
        assertEquals(AnnouncementPriority.NORMAL, AnnouncementPriority.safeFrom(null))
    }
}
