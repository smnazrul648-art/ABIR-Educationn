package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Announcement
import com.example.model.AppConfig
import com.example.viewmodel.AdminViewModel

@Composable
fun AdminSettingsTab(
    adminViewModel: AdminViewModel,
    announcements: List<Announcement>,
    appConfig: AppConfig,
    isBangla: Boolean
) {
    var noticeTitleBn by remember { mutableStateOf("") }
    var noticeBodyBn by remember { mutableStateOf("") }
    var targetClass by remember { mutableStateOf("0") }
    var priority by remember { mutableStateOf("NORMAL") }

    var supportEmail by remember(appConfig.supportEmail) { mutableStateOf(appConfig.supportEmail) }
    var supportPhone by remember(appConfig.supportPhone) { mutableStateOf(appConfig.supportPhone) }
    var latestVersion by remember(appConfig.latestVersionName) { mutableStateOf(appConfig.latestVersionName) }
    var updateNotesBn by remember(appConfig.updateNotesBn) { mutableStateOf(appConfig.updateNotesBn) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isBangla) "নতুন ঘোষণা / নোটিশ পাঠান" else "Send Announcement",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(value = noticeTitleBn, onValueChange = { noticeTitleBn = it }, label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = noticeBodyBn, onValueChange = { noticeBodyBn = it }, label = { Text("বিস্তারিত বার্তা") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = targetClass, onValueChange = { targetClass = it }, label = { Text("শ্রেণি (0 = সকল শ্রেণি, 1-12)") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = priority == "NORMAL", onClick = { priority = "NORMAL" }, label = { Text("NORMAL") })
                        FilterChip(selected = priority == "IMPORTANT", onClick = { priority = "IMPORTANT" }, label = { Text("IMPORTANT") })
                    }
                    Button(
                        enabled = noticeTitleBn.isNotBlank() && noticeBodyBn.isNotBlank(),
                        onClick = {
                            adminViewModel.saveAnnouncement(
                                Announcement(
                                    titleBn = noticeTitleBn,
                                    titleEn = noticeTitleBn,
                                    bodyBn = noticeBodyBn,
                                    bodyEn = noticeBodyBn,
                                    targetClassLevel = targetClass.toIntOrNull()?.coerceIn(0, 12) ?: 0,
                                    priority = priority,
                                    published = true
                                )
                            )
                            noticeTitleBn = ""
                            noticeBodyBn = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isBangla) "নোটিশ প্রকাশ করুন" else "Publish Announcement")
                    }
                }
            }
        }

        items(announcements, key = { it.id }) { ann ->
            AdminItemRow(
                title = ann.displayTitle(isBangla),
                subtitle = "${ann.priority} • Class ${ann.targetClassLevel}",
                onDelete = { adminViewModel.deleteAnnouncement(ann.id) }
            )
        }

        item {
            Spacer(Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isBangla) "অ্যাপ কনফিগারেশন ও সহায়তা তথ্য" else "App Content & Support Config",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(value = supportEmail, onValueChange = { supportEmail = it }, label = { Text("Support Email") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = supportPhone, onValueChange = { supportPhone = it }, label = { Text("Support Phone") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = latestVersion, onValueChange = { latestVersion = it }, label = { Text("Latest Version Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = updateNotesBn, onValueChange = { updateNotesBn = it }, label = { Text("Update Notes (Bangla)") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            adminViewModel.saveAppConfig(
                                appConfig.copy(
                                    supportEmail = supportEmail,
                                    supportPhone = supportPhone,
                                    latestVersionName = latestVersion,
                                    updateNotesBn = updateNotesBn
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isBangla) "কনফিগারেশন সংরক্ষণ" else "Save App Config")
                    }
                }
            }
        }
    }
}
