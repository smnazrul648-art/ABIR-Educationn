package com.example.repository

import android.content.Context
import android.net.Uri
import com.example.model.AdminAccount
import com.example.model.Announcement
import com.example.model.AppConfig
import com.example.model.Chapter
import com.example.model.Course
import com.example.model.Exam
import com.example.model.ExamAttempt
import com.example.model.Lesson
import com.example.model.McqQuestion
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.model.UserProfile
import com.example.util.BanglaDateUtils
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class AdminRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUser(): FirebaseUser {
        return auth.currentUser
            ?: throw IllegalStateException("Admin must be signed in with Google.")
    }

    fun observeAdminAccount(uid: String): Flow<AdminAccount?> =
        db.collection("admins").document(uid)
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(AdminAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else null
            }

    suspend fun initializeFirstAdmin(): Result<Unit> {
        val user = try {
            requireUser()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val path = "admins/${user.uid}"
        return try {
            val docRef = db.collection("admins").document(user.uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(
                    mapOf(
                        "uid" to user.uid,
                        "email" to (user.email ?: ""),
                        "displayName" to (user.displayName?.takeIf { it.isNotBlank() } ?: "Owner Admin").take(100),
                        "initializedAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun seedClasses1To12(): Result<Unit> {
        val path = "classes"
        return try {
            requireUser()
            val namesBn = listOf(
                "প্রথম শ্রেণি", "দ্বিতীয় শ্রেণি", "তৃতীয় শ্রেণি", "চতুর্থ শ্রেণি",
                "পঞ্চম শ্রেণি", "ষষ্ঠ শ্রেণি", "সপ্তম শ্রেণি", "অষ্টম শ্রেণি",
                "নবম শ্রেণি", "দশম শ্রেণি", "একাদশ শ্রেণি", "দ্বাদশ শ্রেণি"
            )
            val batch = db.batch()
            for (level in 1..12) {
                val docRef = db.collection("classes").document("class_$level")
                val existing = docRef.get().await()
                if (!existing.exists()) {
                    batch.set(
                        docRef,
                        mapOf(
                            "level" to level,
                            "nameBn" to namesBn[level - 1],
                            "nameEn" to "Class $level",
                            "descriptionBn" to "${BanglaDateUtils.formatClassLabel(level, true)}-এর সকল বিষয় ও পরীক্ষা",
                            "descriptionEn" to "Complete curriculum & exams for Class $level",
                            "published" to true,
                            "order" to level,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    // --- ADMIN OBSERVATION STREAMS (Includes Drafts & Students) ---
    fun observeAllClasses(): Flow<List<SchoolClass>> =
        db.collection("classes").snapshots().map {
            it.toObjects(SchoolClass::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { c -> c.order }
        }

    fun observeAllSubjects(): Flow<List<Subject>> =
        db.collection("subjects").snapshots().map {
            it.toObjects(Subject::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedWith(compareBy<Subject> { s -> s.classLevel }.thenBy { s -> s.order })
        }

    fun observeAllCourses(): Flow<List<Course>> =
        db.collection("courses").snapshots().map {
            it.toObjects(Course::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { c -> c.classLevel }
        }

    fun observeAllChapters(): Flow<List<Chapter>> =
        db.collection("chapters").snapshots().map {
            it.toObjects(Chapter::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { c -> c.order }
        }

    fun observeAllLessons(): Flow<List<Lesson>> =
        db.collection("lessons").snapshots().map {
            it.toObjects(Lesson::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { l -> l.order }
        }

    fun observeAllExams(): Flow<List<Exam>> =
        db.collection("exams").snapshots().map {
            it.toObjects(Exam::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { e -> e.createdAt?.seconds ?: 0L }
        }

    fun observeAllQuestionsForExam(examId: String): Flow<List<McqQuestion>> =
        db.collection("exams").document(examId).collection("questions").snapshots().map {
            it.toObjects(McqQuestion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { q -> q.order }
        }

    fun observeAllStudents(): Flow<List<UserProfile>> =
        db.collection("users").snapshots().map {
            it.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { u -> u.createdAt?.seconds ?: 0L }
        }

    fun observeAllAttempts(): Flow<List<ExamAttempt>> =
        db.collection("exam_attempts").snapshots().map {
            it.toObjects(ExamAttempt::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { a -> a.submittedAt?.seconds ?: 0L }
        }

    fun observeAllAnnouncements(): Flow<List<Announcement>> =
        db.collection("announcements").snapshots().map {
            it.toObjects(Announcement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { a -> a.createdAt?.seconds ?: 0L }
        }

    // --- ADMIN CRUD MUTATIONS ---

    suspend fun saveClass(schoolClass: SchoolClass): Result<Unit> {
        val docId = schoolClass.id.ifBlank { "class_${schoolClass.level}" }
        val path = "classes/$docId"
        return try {
            requireUser()
            val docRef = db.collection("classes").document(docId)
            val exists = docRef.get().await().exists()
            if (exists) {
                docRef.update(
                    mapOf(
                        "level" to schoolClass.level.coerceIn(1, 12),
                        "nameBn" to schoolClass.nameBn.trim().take(100),
                        "nameEn" to schoolClass.nameEn.trim().take(100),
                        "descriptionBn" to schoolClass.descriptionBn?.take(500),
                        "descriptionEn" to schoolClass.descriptionEn?.take(500),
                        "published" to schoolClass.published,
                        "order" to schoolClass.order.coerceIn(0, 100),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "level" to schoolClass.level.coerceIn(1, 12),
                        "nameBn" to schoolClass.nameBn.trim().take(100),
                        "nameEn" to schoolClass.nameEn.trim().take(100),
                        "descriptionBn" to schoolClass.descriptionBn?.take(500),
                        "descriptionEn" to schoolClass.descriptionEn?.take(500),
                        "published" to schoolClass.published,
                        "order" to schoolClass.order.coerceIn(0, 100),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteClass(classId: String): Result<Unit> = deleteDocument("classes", classId)

    suspend fun saveSubject(subject: Subject): Result<Unit> {
        val docRef = if (subject.id.isBlank()) db.collection("subjects").document()
        else db.collection("subjects").document(subject.id)
        return try {
            requireUser()
            val exists = subject.id.isNotBlank() && docRef.get().await().exists()
            val data = mutableMapOf<String, Any>(
                "classLevel" to subject.classLevel.coerceIn(1, 12),
                "nameBn" to subject.nameBn.trim().take(120),
                "nameEn" to subject.nameEn.trim().take(120),
                "iconName" to subject.iconName.ifBlank { "MenuBook" }.take(60),
                "colorHex" to subject.colorHex.ifBlank { "#1565C0" }.take(12),
                "published" to subject.published,
                "order" to subject.order.coerceIn(0, 500),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (exists) {
                docRef.update(data).await()
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(data).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteSubject(subjectId: String): Result<Unit> = deleteDocument("subjects", subjectId)

    suspend fun saveCourse(course: Course): Result<Unit> {
        val docRef = if (course.id.isBlank()) db.collection("courses").document()
        else db.collection("courses").document(course.id)
        return try {
            requireUser()
            val exists = course.id.isNotBlank() && docRef.get().await().exists()
            val data = mapOf(
                "classLevel" to course.classLevel.coerceIn(1, 12),
                "subjectId" to course.subjectId,
                "subjectNameBn" to course.subjectNameBn.ifBlank { "বিষয়" }.take(120),
                "titleBn" to course.titleBn.trim().take(200),
                "titleEn" to course.titleEn.ifBlank { course.titleBn }.trim().take(200),
                "descriptionBn" to course.descriptionBn?.take(2000),
                "descriptionEn" to course.descriptionEn?.take(2000),
                "instructorName" to course.instructorName.ifBlank { "ABIR Instructor" }.take(120),
                "lessonCount" to course.lessonCount.coerceIn(0, 1000),
                "published" to course.published,
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }.toMutableMap()

            if (exists) {
                docRef.update(data).await()
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(data).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCourse(courseId: String): Result<Unit> = deleteDocument("courses", courseId)

    suspend fun saveChapter(chapter: Chapter): Result<Unit> {
        val docRef = if (chapter.id.isBlank()) db.collection("chapters").document()
        else db.collection("chapters").document(chapter.id)
        return try {
            requireUser()
            val exists = chapter.id.isNotBlank() && docRef.get().await().exists()
            val data = mutableMapOf<String, Any>(
                "courseId" to chapter.courseId,
                "classLevel" to chapter.classLevel.coerceIn(1, 12),
                "titleBn" to chapter.titleBn.trim().take(200),
                "titleEn" to chapter.titleEn.ifBlank { chapter.titleBn }.trim().take(200),
                "order" to chapter.order.coerceIn(0, 500),
                "published" to chapter.published,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (exists) {
                docRef.update(data).await()
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(data).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteChapter(chapterId: String): Result<Unit> = deleteDocument("chapters", chapterId)

    suspend fun uploadPdfToStorage(
        context: Context,
        pdfUri: Uri,
        classLevel: Int,
        fileNamePrefix: String
    ): Result<Pair<String, String>> {
        return try {
            requireUser()
            val storagePath = "notes/class_${classLevel.coerceIn(1, 12)}/${fileNamePrefix}_${System.currentTimeMillis()}.pdf"
            val ref = FirebaseStorage.getInstance().reference.child(storagePath)
            val metadata = StorageMetadata.Builder()
                .setContentType("application/pdf")
                .build()
            context.contentResolver.openInputStream(pdfUri)?.use { stream ->
                ref.putStream(stream, metadata).await()
            } ?: return Result.failure(IllegalStateException("নির্বাচিত PDF ফাইল খোলা যায়নি।"))
            val downloadUrl = ref.downloadUrl.await().toString()
            Result.success(downloadUrl to storagePath)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveLesson(lesson: Lesson): Result<Unit> {
        val docRef = if (lesson.id.isBlank()) db.collection("lessons").document()
        else db.collection("lessons").document(lesson.id)
        return try {
            requireUser()
            val exists = lesson.id.isNotBlank() && docRef.get().await().exists()
            val data = mapOf(
                "courseId" to lesson.courseId,
                "chapterId" to lesson.chapterId,
                "subjectId" to lesson.subjectId,
                "classLevel" to lesson.classLevel.coerceIn(1, 12),
                "titleBn" to lesson.titleBn.trim().take(200),
                "titleEn" to lesson.titleEn.ifBlank { lesson.titleBn }.trim().take(200),
                "contentBn" to lesson.contentBn.take(50000),
                "contentEn" to lesson.contentEn.take(50000),
                "lessonType" to lesson.parsedType().name,
                "pdfUrl" to lesson.pdfUrl?.takeIf { it.isNotBlank() }?.take(1000),
                "pdfStoragePath" to lesson.pdfStoragePath?.takeIf { it.isNotBlank() }?.take(500),
                "videoUrl" to lesson.videoUrl?.takeIf { it.isNotBlank() }?.take(1000),
                "durationMinutes" to lesson.durationMinutes.coerceIn(0, 600),
                "order" to lesson.order.coerceIn(0, 1000),
                "published" to lesson.published,
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }.toMutableMap()

            if (exists) {
                docRef.update(data).await()
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(data).await()
                db.collection("courses").document(lesson.courseId)
                    .update(
                        mapOf(
                            "lessonCount" to FieldValue.increment(1),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteLesson(lessonId: String): Result<Unit> = deleteDocument("lessons", lessonId)

    suspend fun saveExam(exam: Exam): Result<String> {
        val docRef = if (exam.id.isBlank()) db.collection("exams").document()
        else db.collection("exams").document(exam.id)
        return try {
            requireUser()
            val exists = exam.id.isNotBlank() && docRef.get().await().exists()
            val data = mapOf(
                "classLevel" to exam.classLevel.coerceIn(1, 12),
                "subjectId" to exam.subjectId,
                "subjectNameBn" to exam.subjectNameBn.ifBlank { "বিষয়" }.take(120),
                "titleBn" to exam.titleBn.trim().take(200),
                "titleEn" to exam.titleEn.ifBlank { exam.titleBn }.trim().take(200),
                "descriptionBn" to exam.descriptionBn?.take(1000),
                "durationMinutes" to exam.durationMinutes.coerceIn(1, 300),
                "totalMarks" to exam.totalMarks.coerceIn(0.0, 10000.0),
                "marksPerQuestion" to exam.marksPerQuestion.coerceIn(0.25, 100.0),
                "negativeMarkPerWrong" to exam.negativeMarkPerWrong.coerceIn(0.0, 100.0),
                "questionCount" to exam.questionCount.coerceIn(0, 500),
                "published" to exam.published,
                "resultsPublished" to exam.resultsPublished,
                "allowMultipleAttempts" to exam.allowMultipleAttempts,
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }.toMutableMap()

            if (exists) {
                docRef.update(data).await()
                val questionsSnap = docRef.collection("questions").get().await()
                if (!questionsSnap.isEmpty) {
                    val batch = db.batch()
                    for (qDoc in questionsSnap.documents) {
                        batch.update(
                            qDoc.reference,
                            mapOf(
                                "examPublished" to exam.published,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    batch.commit().await()
                }
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(data).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteExam(examId: String): Result<Unit> = deleteDocument("exams", examId)

    suspend fun saveMcqQuestion(exam: Exam, question: McqQuestion): Result<Unit> {
        val qRef = if (question.id.isBlank()) {
            db.collection("exams").document(exam.id).collection("questions").document()
        } else {
            db.collection("exams").document(exam.id).collection("questions").document(question.id)
        }
        return try {
            requireUser()
            val exists = question.id.isNotBlank() && qRef.get().await().exists()
            val cleanOptions = question.options.take(4).map { it.trim().ifBlank { "Option" }.take(500) }
            require(cleanOptions.size == 4) { "Must provide 4 options" }

            val data = mutableMapOf<String, Any>(
                "examId" to exam.id,
                "examPublished" to exam.published,
                "order" to question.order.coerceIn(0, 500),
                "questionBn" to question.questionBn.trim().take(1500),
                "questionEn" to question.questionEn.ifBlank { question.questionBn }.trim().take(1500),
                "options" to cleanOptions,
                "correctOptionIndex" to question.correctOptionIndex.coerceIn(0, 3),
                "explanationBn" to question.explanationBn.take(2000),
                "explanationEn" to question.explanationEn.take(2000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (exists) {
                qRef.update(data).await()
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                qRef.set(data).await()
                val newCount = exam.questionCount + 1
                db.collection("exams").document(exam.id).update(
                    mapOf(
                        "questionCount" to newCount,
                        "totalMarks" to (newCount * exam.marksPerQuestion),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, qRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteMcqQuestion(examId: String, questionId: String): Result<Unit> {
        val path = "exams/$examId/questions/$questionId"
        return try {
            requireUser()
            db.collection("exams").document(examId)
                .collection("questions").document(questionId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveAnnouncement(announcement: Announcement): Result<Unit> {
        val docRef = if (announcement.id.isBlank()) db.collection("announcements").document()
        else db.collection("announcements").document(announcement.id)
        return try {
            requireUser()
            val exists = announcement.id.isNotBlank() && docRef.get().await().exists()
            val data = mutableMapOf<String, Any>(
                "titleBn" to announcement.titleBn.trim().take(200),
                "titleEn" to announcement.titleEn.ifBlank { announcement.titleBn }.trim().take(200),
                "bodyBn" to announcement.bodyBn.trim().take(3000),
                "bodyEn" to announcement.bodyEn.ifBlank { announcement.bodyBn }.trim().take(3000),
                "targetClassLevel" to announcement.targetClassLevel.coerceIn(0, 12),
                "priority" to announcement.parsedPriority().name,
                "published" to announcement.published,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (exists) {
                docRef.update(data).await()
            } else {
                data["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(data).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteAnnouncement(id: String): Result<Unit> = deleteDocument("announcements", id)

    suspend fun toggleStudentSuspension(userId: String, suspend: Boolean): Result<Unit> {
        val path = "users/$userId"
        return try {
            requireUser()
            db.collection("users").document(userId).update(
                mapOf(
                    "suspended" to suspend,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleAttemptPublished(attemptId: String, published: Boolean): Result<Unit> {
        val path = "exam_attempts/$attemptId"
        return try {
            requireUser()
            db.collection("exam_attempts").document(attemptId).update(
                mapOf("resultPublished" to published)
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun saveAppConfig(config: AppConfig): Result<Unit> {
        val path = "app_config/main"
        return try {
            requireUser()
            val payload = mapOf(
                "latestVersionCode" to config.latestVersionCode.coerceAtLeast(1),
                "latestVersionName" to config.latestVersionName.trim().take(40),
                "updateNotesBn" to config.updateNotesBn.take(2000),
                "updateNotesEn" to config.updateNotesEn.take(2000),
                "supportEmail" to config.supportEmail.trim().take(200),
                "supportPhone" to config.supportPhone.trim().take(40),
                "privacyPolicyBn" to config.privacyPolicyBn.take(20000),
                "privacyPolicyEn" to config.privacyPolicyEn.take(20000),
                "termsBn" to config.termsBn.take(20000),
                "termsEn" to config.termsEn.take(20000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_config").document("main").set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun deleteDocument(collection: String, docId: String): Result<Unit> {
        val path = "$collection/$docId"
        return try {
            requireUser()
            db.collection(collection).document(docId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
