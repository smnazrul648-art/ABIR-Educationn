package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.local.OfflineNoteEntity
import com.example.model.Lesson
import com.example.model.LessonType
import com.example.ui.components.NativePdfViewer
import com.example.ui.components.StatusBadge
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonViewerScreen(
    lesson: Lesson,
    language: AppLanguage,
    isBookmarked: Boolean,
    isCompleted: Boolean,
    offlineNote: OfflineNoteEntity?,
    isDownloading: Boolean,
    onBack: () -> Unit,
    onToggleBookmark: () -> Unit,
    onDownloadOffline: () -> Unit,
    onMarkCompleted: () -> Unit
) {
    val context = LocalContext.current
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    var fontSizeSp by remember { mutableIntStateOf(16) }

    val localPdfFile = remember(offlineNote) {
        offlineNote?.localPdfPath?.let { path -> File(path).takeIf { it.exists() && it.length() > 0L } }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(lesson.displayTitle(isBangla), maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { if (fontSizeSp > 12) fontSizeSp -= 2 }) {
                        Icon(Icons.Default.TextDecrease, contentDescription = "Decrease text size")
                    }
                    IconButton(onClick = { if (fontSizeSp < 26) fontSizeSp += 2 }) {
                        Icon(Icons.Default.TextIncrease, contentDescription = "Increase text size")
                    }
                    IconButton(onClick = onToggleBookmark) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadge(text = lesson.lessonType)
                if (isCompleted) {
                    StatusBadge(
                        text = strings.completedBadge,
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        showCheck = true
                    )
                }
                if (offlineNote != null) {
                    StatusBadge(
                        text = if (isBangla) "অফলাইনে সংরক্ষিত" else "Saved Offline",
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            Text(
                text = lesson.displayTitle(isBangla),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            // Video Player Section
            val videoUrl = lesson.videoUrl?.takeIf { it.isNotBlank() }
            if (lesson.parsedType() == LessonType.VIDEO || videoUrl != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        if (videoUrl != null && (videoUrl.endsWith(".mp4", true) || videoUrl.endsWith(".m3u8", true))) {
                            AndroidView(
                                factory = { ctx ->
                                    VideoView(ctx).apply {
                                        val controller = MediaController(ctx)
                                        controller.setAnchorView(this)
                                        setMediaController(controller)
                                        setVideoURI(Uri.parse(videoUrl))
                                        requestFocus()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(220.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                        if (videoUrl != null) {
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (isBangla) "ভিডিও প্লেয়ারে খুলুন" else "Open Video Externally")
                            }
                        }
                    }
                }
            }

            // PDF Viewer & Offline Download Section
            val hasPdf = !lesson.pdfUrl.isNullOrBlank() || !lesson.pdfStoragePath.isNullOrBlank() || localPdfFile != null
            if (hasPdf) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isBangla) "PDF স্টাডি নোট" else "PDF Study Note",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (isDownloading) {
                                CircularProgressIndicator(modifier = Modifier.height(24.dp).width(24.dp), strokeWidth = 2.dp)
                            }
                        }

                        Spacer(Modifier.height(10.dp))

                        if (localPdfFile != null) {
                            NativePdfViewer(pdfFile = localPdfFile, isBangla = isBangla)
                        } else {
                            Text(
                                text = if (isBangla) "অ্যাপের ভেতরে পড়তে ও অফলাইনে সংরক্ষণ করতে PDF ডাউনলোড করুন।" else "Download this PDF to read inside the app and access it offline.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = onDownloadOffline,
                                enabled = !isDownloading,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(strings.downloadOffline)
                            }
                            lesson.pdfUrl?.takeIf { it.startsWith("http") }?.let { url ->
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (isBangla) "ব্রাউজারে PDF খুলুন" else "Open PDF in Browser")
                                }
                            }
                        }
                    }
                }
            }

            // Text Notes Body
            val bodyText = lesson.displayContent(isBangla)
            if (bodyText.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Text(
                        text = bodyText,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = fontSizeSp.sp,
                            lineHeight = (fontSizeSp + 10).sp
                        ),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            // Bottom Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDownloadOffline,
                    enabled = !isDownloading,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = if (offlineNote != null) Icons.Default.DownloadDone else Icons.Default.Download,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (offlineNote != null) (if (isBangla) "সংরক্ষিত" else "Saved") else strings.downloadOffline)
                }

                Button(
                    onClick = onMarkCompleted,
                    enabled = !isCompleted,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (isCompleted) strings.completedBadge else strings.markComplete)
                }
            }
        }
    }
}
