package com.example.local

import android.content.Context
import com.example.model.Lesson
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

class OfflineRepository(private val context: Context) {
    private val dao = AppDatabase.getInstance(context).offlineNoteDao()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun observeOfflineNotes(): Flow<List<OfflineNoteEntity>> = dao.observeAll()

    suspend fun getOfflineNote(lessonId: String): OfflineNoteEntity? = dao.getByLessonId(lessonId)

    suspend fun saveLessonOffline(lesson: Lesson): Result<OfflineNoteEntity> = withContext(Dispatchers.IO) {
        try {
            val notesDir = File(context.filesDir, "offline_notes").apply { mkdirs() }
            var localPdfPath: String? = null
            var fileSize = (lesson.contentBn.length + lesson.contentEn.length).toLong()

            val pdfUrl = lesson.pdfUrl?.takeIf { it.isNotBlank() }
            val storagePath = lesson.pdfStoragePath?.takeIf { it.isNotBlank() }

            if (storagePath != null || pdfUrl != null) {
                val targetFile = File(notesDir, "${lesson.id}.pdf")
                if (storagePath != null && (pdfUrl == null || !pdfUrl.startsWith("http"))) {
                    FirebaseStorage.getInstance().reference.child(storagePath).getFile(targetFile).await()
                } else if (pdfUrl != null) {
                    if (pdfUrl.startsWith("gs://")) {
                        FirebaseStorage.getInstance().getReferenceFromUrl(pdfUrl).getFile(targetFile).await()
                    } else {
                        val request = Request.Builder().url(pdfUrl).build()
                        httpClient.newCall(request).execute().use { response ->
                            if (!response.isSuccessful) {
                                error("PDF ডাউনলোড ব্যর্থ হয়েছে (HTTP ${response.code})")
                            }
                            val body = response.body ?: error("খালি PDF ফাইল পাওয়া গেছে")
                            targetFile.outputStream().use { out ->
                                body.byteStream().copyTo(out)
                            }
                        }
                    }
                }
                if (targetFile.exists() && targetFile.length() > 0L) {
                    localPdfPath = targetFile.absolutePath
                    fileSize = targetFile.length()
                }
            }

            val entity = OfflineNoteEntity(
                lessonId = lesson.id,
                courseId = lesson.courseId,
                subjectId = lesson.subjectId,
                classLevel = lesson.classLevel,
                titleBn = lesson.titleBn,
                titleEn = lesson.titleEn,
                contentBn = lesson.contentBn,
                contentEn = lesson.contentEn,
                lessonType = lesson.lessonType,
                localPdfPath = localPdfPath,
                fileSizeBytes = fileSize,
                savedAtMillis = System.currentTimeMillis()
            )
            dao.upsert(entity)
            Result.success(entity)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun removeOfflineNote(lessonId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val existing = dao.getByLessonId(lessonId)
            existing?.localPdfPath?.let { path ->
                val file = File(path)
                if (file.exists()) file.delete()
            }
            dao.deleteByLessonId(lessonId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
