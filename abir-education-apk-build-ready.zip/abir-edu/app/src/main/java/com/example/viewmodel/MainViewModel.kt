package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.i18n.AppLanguage
import com.example.local.OfflineNoteEntity
import com.example.local.OfflineRepository
import com.example.model.Announcement
import com.example.model.AppConfig
import com.example.model.Bookmark
import com.example.model.Chapter
import com.example.model.Course
import com.example.model.Lesson
import com.example.model.LessonProgress
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.repository.StudentRepository
import com.example.util.extractRootFirestoreMessage
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val studentRepository: StudentRepository,
    private val offlineRepository: OfflineRepository,
    private val currentUser: FirebaseUser
) : ViewModel() {

    private val currentUserId: String = currentUser.uid

    private val _selectedClassFilter = MutableStateFlow<Int?>(null) // null = user's class or all
    val selectedClassFilter: StateFlow<Int?> = _selectedClassFilter.asStateFlow()

    private val _selectedSubjectId = MutableStateFlow<String?>(null)
    val selectedSubjectId: StateFlow<String?> = _selectedSubjectId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeCourseId = MutableStateFlow<String?>(null)

    private val _downloadingLessonIds = MutableStateFlow<Set<String>>(emptySet())
    val downloadingLessonIds: StateFlow<Set<String>> = _downloadingLessonIds.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events = _events.asSharedFlow()

    val userProfile: StateFlow<UiState<UserProfile?>> = studentRepository.observeUserProfile(currentUserId)
        .toUiState("প্রোফাইল লোড করা যায়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val language: StateFlow<AppLanguage> = userProfile
        .map { state ->
            when (state) {
                is UiState.Success -> AppLanguage.fromCode(state.data?.preferredLanguage)
                else -> AppLanguage.BN
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppLanguage.BN)

    val darkMode: StateFlow<Boolean> = userProfile
        .map { state ->
            when (state) {
                is UiState.Success -> state.data?.darkMode ?: false
                else -> false
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)

    val classesState: StateFlow<UiState<List<SchoolClass>>> = studentRepository.observePublishedClasses()
        .toUiState("শ্রেণি তালিকা লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val subjectsState: StateFlow<UiState<List<Subject>>> = studentRepository.observePublishedSubjects()
        .toUiState("বিষয় তালিকা লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val coursesState: StateFlow<UiState<List<Course>>> = studentRepository.observePublishedCourses()
        .toUiState("কোর্স লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val allLessonsState: StateFlow<UiState<List<Lesson>>> = studentRepository.observeAllPublishedLessons()
        .toUiState("পাঠসমূহ লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val announcementsState: StateFlow<UiState<List<Announcement>>> = studentRepository.observeAnnouncements()
        .toUiState("নোটিশ লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val bookmarksState: StateFlow<UiState<List<Bookmark>>> = studentRepository.observeBookmarks(currentUserId)
        .toUiState("বুকমার্ক লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val progressState: StateFlow<UiState<List<LessonProgress>>> = studentRepository.observeProgress(currentUserId)
        .toUiState("শেখার অগ্রগতি লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val offlineNotes: StateFlow<List<OfflineNoteEntity>> = offlineRepository.observeOfflineNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val appConfig: StateFlow<AppConfig> = studentRepository.observeAppConfig()
        .catch { error ->
            if (error is CancellationException) throw error
            emit(AppConfig())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppConfig())

    val activeCourseChapters: StateFlow<UiState<List<Chapter>>> = _activeCourseId
        .flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(UiState.Success(emptyList()))
            else studentRepository.observeChaptersForCourse(cid).toUiState("অধ্যায় লোড হয়নি")
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val activeCourseLessons: StateFlow<UiState<List<Lesson>>> = _activeCourseId
        .flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(UiState.Success(emptyList()))
            else studentRepository.observeLessonsForCourse(cid).toUiState("লেসন লোড হয়নি")
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val filteredCourses: StateFlow<List<Course>> = combine(
        coursesState,
        selectedClassFilter,
        selectedSubjectId,
        searchQuery
    ) { coursesUi, classFilter, subjectId, query ->
        val list = (coursesUi as? UiState.Success)?.data ?: emptyList()
        val q = query.trim().lowercase()
        list.filter { c ->
            val matchesClass = classFilter == null || c.classLevel == classFilter
            val matchesSubject = subjectId == null || c.subjectId == subjectId
            val matchesQuery = q.isEmpty() ||
                c.titleBn.lowercase().contains(q) ||
                c.titleEn.lowercase().contains(q) ||
                c.subjectNameBn.lowercase().contains(q) ||
                c.instructorName.lowercase().contains(q)
            matchesClass && matchesSubject && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        viewModelScope.launch {
            val res = studentRepository.ensureUserProfileExists(currentUser)
            if (res.isFailure) {
                Log.w(TAG, "Profile sync note: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    fun selectClassFilter(level: Int?) {
        _selectedClassFilter.value = level
        _selectedSubjectId.value = null
    }

    fun selectSubjectFilter(subjectId: String?) {
        _selectedSubjectId.value = if (_selectedSubjectId.value == subjectId) null else subjectId
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setActiveCourse(courseId: String) {
        _activeCourseId.value = courseId
    }

    fun updateClassLevel(level: Int) {
        viewModelScope.launch {
            val res = studentRepository.updateProfilePreferences(currentUserId, classLevel = level)
            if (res.isSuccess) {
                _selectedClassFilter.value = level
                _events.tryEmit("শ্রেণি আপডেট করা হয়েছে")
            } else {
                _events.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "শ্রেণি আপডেট ব্যর্থ হয়েছে")
            }
        }
    }

    fun updateLanguage(lang: AppLanguage) {
        viewModelScope.launch {
            studentRepository.updateProfilePreferences(currentUserId, preferredLanguage = lang.code)
        }
    }

    fun updateDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            studentRepository.updateProfilePreferences(currentUserId, darkMode = enabled)
        }
    }

    fun updateLeaderboardPrivacy(optIn: Boolean) {
        viewModelScope.launch {
            studentRepository.updateProfilePreferences(currentUserId, leaderboardOptIn = optIn)
        }
    }

    fun updateDisplayName(newName: String) {
        viewModelScope.launch {
            val res = studentRepository.updateProfilePreferences(currentUserId, name = newName)
            if (res.isSuccess) _events.tryEmit("প্রোফাইল নাম আপডেট হয়েছে")
            else _events.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "আপডেট ব্যর্থ হয়েছে")
        }
    }

    fun toggleBookmark(lesson: Lesson, currentlyBookmarked: Boolean) {
        viewModelScope.launch {
            val res = studentRepository.toggleBookmark(currentUserId, lesson, currentlyBookmarked)
            if (res.isSuccess) {
                _events.tryEmit(if (currentlyBookmarked) "বুকমার্ক সরানো হয়েছে" else "লেসন সংরক্ষণ করা হয়েছে")
            } else {
                _events.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "বুকমার্ক ব্যর্থ হয়েছে")
            }
        }
    }

    fun markLessonCompleted(lesson: Lesson, completed: Boolean = true) {
        viewModelScope.launch {
            val res = studentRepository.markLessonProgress(currentUserId, lesson, completed)
            if (res.isSuccess && completed) {
                _events.tryEmit("অভিনন্দন! পাঠটি সম্পন্ন হিসেবে সংরক্ষিত হয়েছে")
            }
        }
    }

    fun downloadLessonOffline(lesson: Lesson) {
        viewModelScope.launch {
            _downloadingLessonIds.value = _downloadingLessonIds.value + lesson.id
            val res = offlineRepository.saveLessonOffline(lesson)
            _downloadingLessonIds.value = _downloadingLessonIds.value - lesson.id
            if (res.isSuccess) {
                _events.tryEmit("অফলাইন পড়ার জন্য নোট সংরক্ষণ সম্পন্ন!")
            } else {
                _events.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "অফলাইন ডাউনলোড ব্যর্থ হয়েছে")
            }
        }
    }

    fun removeOfflineNote(lessonId: String) {
        viewModelScope.launch {
            val res = offlineRepository.removeOfflineNote(lessonId)
            if (res.isSuccess) _events.tryEmit("অফলাইন কপি মুছে ফেলা হয়েছে")
        }
    }

    private fun <T> Flow<T>.toUiState(fallback: String): Flow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, fallback, root)
                emit(UiState.Error(extractRootFirestoreMessage(root, fallback)))
            }

    private companion object {
        const val TAG = "MainViewModel"
    }
}
