package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Exam
import com.example.model.McqQuestion
import com.example.model.Subject
import com.example.util.BanglaDateUtils
import com.example.viewmodel.AdminViewModel

@Composable
fun AdminExamTab(
    adminViewModel: AdminViewModel,
    subjects: List<Subject>,
    exams: List<Exam>,
    isBangla: Boolean
) {
    val selectedExamId by adminViewModel.selectedExamIdForQuestions.collectAsStateWithLifecycle()
    val questions by adminViewModel.selectedExamQuestions.collectAsStateWithLifecycle()

    var showCreateExamDialog by remember { mutableStateOf(false) }
    var showAddQuestionDialog by remember { mutableStateOf(false) }

    val selectedExam = exams.firstOrNull { it.id == selectedExamId }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = { showCreateExamDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (isBangla) "নতুন পরীক্ষা তৈরি করুন" else "Create New Exam")
            }
        }

        items(exams, key = { it.id }) { exam ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(
                    if (exam.id == selectedExamId) 2.dp else 1.dp,
                    if (exam.id == selectedExamId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(exam.displayTitle(isBangla), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                "${BanglaDateUtils.formatClassLabel(exam.classLevel, isBangla)} • ${exam.durationMinutes} min • -${exam.negativeMarkPerWrong} neg • ${exam.questionCount} Q",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { adminViewModel.deleteExam(exam.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Exam", tint = MaterialTheme.colorScheme.error)
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                adminViewModel.selectExamForQuestions(exam.id)
                                showAddQuestionDialog = true
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isBangla) "MCQ প্রশ্ন যোগ/দেখুন" else "Manage MCQs")
                        }
                        OutlinedButton(
                            onClick = {
                                adminViewModel.saveExam(exam.copy(resultsPublished = !exam.resultsPublished))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (exam.resultsPublished) "Results: On" else "Publish Results")
                        }
                    }
                }
            }
        }

        if (selectedExam != null) {
            item {
                Text(
                    text = "${selectedExam.displayTitle(isBangla)} — ${if (isBangla) "প্রশ্ন তালিকা" else "Questions"} (${questions.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(questions, key = { it.id }) { q ->
                AdminItemRow(
                    title = "${q.order}. ${q.displayQuestion(isBangla)}",
                    subtitle = "Ans: ${q.options.getOrNull(q.correctOptionIndex) ?: ""}",
                    onDelete = { adminViewModel.deleteMcqQuestion(selectedExam.id, q.id) }
                )
            }
        }
    }

    if (showCreateExamDialog) {
        var selectedSubject by remember { mutableStateOf(subjects.firstOrNull()) }
        var titleBn by remember { mutableStateOf("") }
        var titleEn by remember { mutableStateOf("") }
        var durationMin by remember { mutableStateOf("20") }
        var marksPerQ by remember { mutableStateOf("1.0") }
        var negativeMark by remember { mutableStateOf("0.25") }
        var allowMulti by remember { mutableStateOf(false) }
        var publishResultsImmediate by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showCreateExamDialog = false },
            title = { Text(if (isBangla) "নতুন MCQ পরীক্ষা" else "Create MCQ Exam") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Subject:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        subjects.forEach { sub ->
                            FilterChip(
                                selected = selectedSubject?.id == sub.id,
                                onClick = { selectedSubject = sub },
                                label = { Text("${sub.nameBn} (${sub.classLevel})") }
                            )
                        }
                    }
                    OutlinedTextField(value = titleBn, onValueChange = { titleBn = it }, label = { Text("পরীক্ষার নাম (বাংলা)") })
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("Exam Title (English)") })
                    OutlinedTextField(value = durationMin, onValueChange = { durationMin = it }, label = { Text("সময়সীমা (মিনিট)") })
                    OutlinedTextField(value = marksPerQ, onValueChange = { marksPerQ = it }, label = { Text("প্রতি সঠিক উত্তরের নম্বর") })
                    OutlinedTextField(value = negativeMark, onValueChange = { negativeMark = it }, label = { Text("ভুলের জন্য নেগেটিভ মার্ক") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isBangla) "একাধিকবার পরীক্ষা দেওয়া যাবে?" else "Allow Multiple Attempts", modifier = Modifier.weight(1f))
                        Switch(checked = allowMulti, onCheckedChange = { allowMulti = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isBangla) "তাৎক্ষণিক ফলাফল প্রকাশ" else "Publish Results Immediately", modifier = Modifier.weight(1f))
                        Switch(checked = publishResultsImmediate, onCheckedChange = { publishResultsImmediate = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedSubject != null && titleBn.isNotBlank(),
                    onClick = {
                        val sub = selectedSubject!!
                        adminViewModel.saveExam(
                            Exam(
                                classLevel = sub.classLevel,
                                subjectId = sub.id,
                                subjectNameBn = sub.nameBn,
                                titleBn = titleBn,
                                titleEn = titleEn.ifBlank { titleBn },
                                durationMinutes = durationMin.toIntOrNull()?.coerceIn(1, 300) ?: 20,
                                marksPerQuestion = marksPerQ.toDoubleOrNull()?.coerceIn(0.25, 100.0) ?: 1.0,
                                negativeMarkPerWrong = negativeMark.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 0.0,
                                published = true,
                                resultsPublished = publishResultsImmediate,
                                allowMultipleAttempts = allowMulti
                            )
                        ) { createdId ->
                            adminViewModel.selectExamForQuestions(createdId)
                        }
                        showCreateExamDialog = false
                    }
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreateExamDialog = false }) { Text("Cancel") } }
        )
    }

    if (showAddQuestionDialog && selectedExam != null) {
        var qBn by remember { mutableStateOf("") }
        var opt0 by remember { mutableStateOf("") }
        var opt1 by remember { mutableStateOf("") }
        var opt2 by remember { mutableStateOf("") }
        var opt3 by remember { mutableStateOf("") }
        var correctIdx by remember { mutableIntStateOf(0) }
        var expBn by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddQuestionDialog = false },
            title = { Text(if (isBangla) "নতুন MCQ প্রশ্ন যোগ করুন" else "Add MCQ Question") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = qBn, onValueChange = { qBn = it }, label = { Text("প্রশ্ন") }, minLines = 2)
                    OutlinedTextField(value = opt0, onValueChange = { opt0 = it }, label = { Text("অপশন ক (A)") })
                    OutlinedTextField(value = opt1, onValueChange = { opt1 = it }, label = { Text("অপশন খ (B)") })
                    OutlinedTextField(value = opt2, onValueChange = { opt2 = it }, label = { Text("অপশন গ (C)") })
                    OutlinedTextField(value = opt3, onValueChange = { opt3 = it }, label = { Text("অপশন ঘ (D)") })
                    Text(if (isBangla) "সঠিক উত্তর:" else "Correct Option:", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ক", "খ", "গ", "ঘ").forEachIndexed { idx, lbl ->
                            FilterChip(selected = correctIdx == idx, onClick = { correctIdx = idx }, label = { Text(lbl) })
                        }
                    }
                    OutlinedTextField(value = expBn, onValueChange = { expBn = it }, label = { Text("ব্যাখ্যা (Explanation)") }, minLines = 2)
                }
            },
            confirmButton = {
                Button(
                    enabled = qBn.isNotBlank() && opt0.isNotBlank() && opt1.isNotBlank() && opt2.isNotBlank() && opt3.isNotBlank(),
                    onClick = {
                        adminViewModel.saveMcqQuestion(
                            exam = selectedExam,
                            question = McqQuestion(
                                examId = selectedExam.id,
                                examPublished = selectedExam.published,
                                order = questions.size + 1,
                                questionBn = qBn,
                                questionEn = qBn,
                                options = listOf(opt0, opt1, opt2, opt3),
                                correctOptionIndex = correctIdx,
                                explanationBn = expBn,
                                explanationEn = expBn
                            )
                        )
                        showAddQuestionDialog = false
                    }
                ) { Text("Add Question") }
            },
            dismissButton = { TextButton(onClick = { showAddQuestionDialog = false }) { Text("Cancel") } }
        )
    }
}
