package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.config.AdminConfig
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.model.AppConfig
import com.example.model.Bookmark
import com.example.model.UserProfile
import com.example.ui.components.ClassFilterRow
import com.example.ui.components.StatusBadge
import com.example.util.BanglaDateUtils

@Composable
fun ProfileScreen(
    profile: UserProfile,
    isOwnerEmailVerified: Boolean,
    language: AppLanguage,
    darkMode: Boolean,
    bookmarks: List<Bookmark>,
    appConfig: AppConfig,
    onUpdateName: (String) -> Unit,
    onSelectClass: (Int) -> Unit,
    onToggleLanguage: (AppLanguage) -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onToggleLeaderboardPrivacy: (Boolean) -> Unit,
    onOpenAdminPanel: () -> Unit,
    onSignOut: () -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)

    var showEditNameDialog by remember { mutableStateOf(false) }
    var infoDialogTitle by remember { mutableStateOf<String?>(null) }
    var infoDialogBody by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Profile Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = profile.photoUrl,
                        contentDescription = profile.name,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = profile.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { showEditNameDialog = true }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Name", modifier = Modifier.size(18.dp))
                            }
                        }
                        Text(
                            text = profile.email,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(6.dp))
                        StatusBadge(text = BanglaDateUtils.formatClassLabel(profile.classLevel, isBangla))
                    }
                }
            }
        }

        // Class Selection
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(strings.selectClass, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    ClassFilterRow(
                        selectedClass = profile.classLevel,
                        allLabel = strings.allClasses,
                        isBangla = isBangla,
                        includeAllOption = false,
                        onSelect = { lvl -> lvl?.let(onSelectClass) }
                    )
                }
            }
        }

        // Owner Admin Panel Entry (Only visible to the exact verified owner email; backend enforces all rules)
        if (isOwnerEmailVerified) {
            item {
                Button(
                    onClick = onOpenAdminPanel,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("admin_panel_button")
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text(strings.adminPanelTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Settings Card: Language, Dark Mode, Leaderboard Privacy
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(strings.languageTitle, style = MaterialTheme.typography.titleSmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = language == AppLanguage.BN,
                                onClick = { onToggleLanguage(AppLanguage.BN) },
                                label = { Text(strings.banglaLabel) }
                            )
                            FilterChip(
                                selected = language == AppLanguage.EN,
                                onClick = { onToggleLanguage(AppLanguage.EN) },
                                label = { Text(strings.englishLabel) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(strings.darkModeTitle, style = MaterialTheme.typography.titleSmall)
                        }
                        Switch(checked = darkMode, onCheckedChange = onToggleDarkMode)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Visibility, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(strings.leaderboardPrivacyTitle, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    strings.leaderboardPrivacyDesc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(checked = profile.leaderboardOptIn, onCheckedChange = onToggleLeaderboardPrivacy)
                    }
                }
            }
        }

        // Bookmarks Count
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Bookmark, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "${strings.bookmarksTitle}: ${BanglaDateUtils.formatNumber(bookmarks.size, isBangla)}",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }

        // Info Pages: Help & Contact, Privacy Policy, Terms, App Version & Update
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column {
                    ProfileLinkRow(
                        icon = Icons.Default.HelpOutline,
                        title = strings.helpContactTitle,
                        onClick = {
                            infoDialogTitle = strings.helpContactTitle
                            infoDialogBody = if (isBangla) {
                                "ইমেইল: ${appConfig.supportEmail}\nফোন: ${appConfig.supportPhone}\n\nযেকোনো কোর্স বা পরীক্ষা সংক্রান্ত সহায়তার জন্য যোগাযোগ করুন।"
                            } else {
                                "Email: ${appConfig.supportEmail}\nPhone: ${appConfig.supportPhone}\n\nContact us for course, PDF, or exam support."
                            }
                        }
                    )
                    ProfileLinkRow(
                        icon = Icons.Default.PrivacyTip,
                        title = strings.privacyPolicyTitle,
                        onClick = {
                            infoDialogTitle = strings.privacyPolicyTitle
                            infoDialogBody = if (isBangla) appConfig.privacyPolicyBn else appConfig.privacyPolicyEn
                        }
                    )
                    ProfileLinkRow(
                        icon = Icons.Default.Description,
                        title = strings.termsOfServiceTitle,
                        onClick = {
                            infoDialogTitle = strings.termsOfServiceTitle
                            infoDialogBody = if (isBangla) appConfig.termsBn else appConfig.termsEn
                        }
                    )
                    ProfileLinkRow(
                        icon = Icons.Default.Info,
                        title = "${strings.appVersionTitle}: v${AdminConfig.APP_VERSION_NAME}",
                        onClick = {
                            infoDialogTitle = strings.appVersionTitle
                            val hasUpdate = appConfig.latestVersionCode > AdminConfig.APP_VERSION_CODE
                            infoDialogBody = if (isBangla) {
                                "বর্তমান সংস্করণ: ${AdminConfig.APP_VERSION_NAME} (কোড ${BanglaDateUtils.toBanglaDigits(AdminConfig.APP_VERSION_CODE)})\n" +
                                    "সর্বশেষ সংস্করণ: ${appConfig.latestVersionName}\n\n" +
                                    (if (hasUpdate) "নতুন আপডেট পাওয়া গেছে!\n" else "") +
                                    appConfig.updateNotesBn
                            } else {
                                "Installed Version: ${AdminConfig.APP_VERSION_NAME} (Code ${AdminConfig.APP_VERSION_CODE})\n" +
                                    "Latest Version: ${appConfig.latestVersionName}\n\n" +
                                    (if (hasUpdate) "Update Available!\n" else "") +
                                    appConfig.updateNotesEn
                            }
                        }
                    )
                }
            }
        }

        // Sign Out
        item {
            OutlinedButton(
                onClick = onSignOut,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(strings.signOut, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showEditNameDialog) {
        var nameInput by remember(profile.name) { mutableStateOf(profile.name) }
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            title = { Text(if (isBangla) "নাম পরিবর্তন করুন" else "Edit Name") },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    singleLine = true,
                    label = { Text(if (isBangla) "আপনার নাম" else "Full Name") }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isNotBlank()) {
                            onUpdateName(nameInput.trim())
                            showEditNameDialog = false
                        }
                    }
                ) { Text(strings.saveLabel) }
            },
            dismissButton = {
                TextButton(onClick = { showEditNameDialog = false }) { Text(strings.cancelLabel) }
            }
        )
    }

    if (infoDialogTitle != null && infoDialogBody != null) {
        AlertDialog(
            onDismissRequest = {
                infoDialogTitle = null
                infoDialogBody = null
            },
            title = { Text(infoDialogTitle!!) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(infoDialogBody!!, style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {
                Button(onClick = {
                    infoDialogTitle = null
                    infoDialogBody = null
                }) { Text("OK") }
            }
        )
    }
}

@Composable
private fun ProfileLinkRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text(title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
    }
}
