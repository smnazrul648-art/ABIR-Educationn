package com.example.util

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object BanglaDateUtils {
    private val banglaDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    private val banglaMonths = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val banglaSeasonMonths = arrayOf(
        "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র", "বৈশাখ", "জ্যৈষ্ঠ",
        "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন", "কার্তিক", "অগ্রহায়ণ"
    )

    fun toBanglaDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(banglaDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toBanglaDigits(number: Int): String = toBanglaDigits(number.toString())
    fun toBanglaDigits(number: Long): String = toBanglaDigits(number.toString())

    fun formatNumber(value: Number, isBangla: Boolean): String {
        val str = if (value is Double || value is Float) {
            val d = value.toDouble()
            if (d % 1.0 == 0.0) d.toInt().toString() else String.format(Locale.US, "%.2f", d)
        } else {
            value.toString()
        }
        return if (isBangla) toBanglaDigits(str) else str
    }

    fun formatClassLabel(level: Int, isBangla: Boolean): String {
        return if (isBangla) {
            "শ্রেণি ${toBanglaDigits(level)}"
        } else {
            "Class $level"
        }
    }

    fun formatTimer(remainingSeconds: Int, isBangla: Boolean): String {
        val safe = remainingSeconds.coerceAtLeast(0)
        val mins = safe / 60
        val secs = safe % 60
        val raw = String.format(Locale.US, "%02d:%02d", mins, secs)
        return if (isBangla) toBanglaDigits(raw) else raw
    }

    fun formatReadableDateTime(timestamp: Timestamp?, isBangla: Boolean): String {
        val date = timestamp?.toDate() ?: Date()
        return formatReadableDateTime(date, isBangla)
    }

    fun formatReadableDateTime(millis: Long, isBangla: Boolean): String {
        return formatReadableDateTime(Date(millis), isBangla)
    }

    fun formatReadableDateTime(date: Date, isBangla: Boolean): String {
        if (!isBangla) {
            val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
            return fmt.format(date)
        }
        val cal = Calendar.getInstance().apply { time = date }
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val monthIdx = cal.get(Calendar.MONTH)
        val year = cal.get(Calendar.YEAR)
        val hour24 = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        val period = when (hour24) {
            in 4..11 -> "সকাল"
            in 12..15 -> "দুপুর"
            in 16..17 -> "বিকাল"
            in 18..19 -> "সন্ধ্যা"
            else -> "রাত"
        }
        val banglaCalMonth = getApproximateBanglaMonth(cal)
        val timeFormatted = String.format(Locale.US, "%02d:%02d", hour12, minute)
        return "${toBanglaDigits(day)} ${banglaMonths[monthIdx]} ${toBanglaDigits(year)} ($banglaCalMonth), $period ${toBanglaDigits(timeFormatted)}"
    }

    private fun getApproximateBanglaMonth(cal: Calendar): String {
        val month = cal.get(Calendar.MONTH) // 0 = Jan
        val day = cal.get(Calendar.DAY_OF_MONTH)
        // Approximate Bangladesh Bangla calendar transition around 14th-15th
        val splitDay = if (month in listOf(0, 1, 2, 3, 4)) 14 else 15
        val idx = if (day >= splitDay) (month + 1) % 12 else month
        return banglaSeasonMonths[idx]
    }
}
