package com.example.config

/**
 * UI-level hint for the single owner administrator email.
 * Real authorization is enforced exclusively on the backend by
 * firestore.rules and storage.rules (request.auth.token.email_verified == true
 * && request.auth.token.email == OWNER_ADMIN_EMAIL) plus /admins/{uid}.
 */
object AdminConfig {
    const val OWNER_ADMIN_EMAIL = "smnazrul648@gmail.com"
    const val APP_VERSION_NAME = "1.0.0"
    const val APP_VERSION_CODE = 1
}
