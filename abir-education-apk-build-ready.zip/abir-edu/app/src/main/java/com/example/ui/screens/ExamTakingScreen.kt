package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.util.BanglaDateUtils
import com.example.viewmodel.ActiveExamSession

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamTakingScreen(
    session: ActiveExamSession,
    language: AppLanguage,
    onSelectOption: (String, Int) -> Unit,
    onNavigateQuestion: (Int) -> Unit,
    onSubmit: () -> Unit,
    onExitWithoutSubmitting: () -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    var showConfirmSubmit by remember { mutableStateOf(false) }
    var showExitConfirm by remember { mutableStateOf(false) }

    BackHandler {
        showExitConfirm = true
    }

    val currentQuestion = session.questions.getOrNull(session.currentQuestionIndex)
    val isTimeUrgent = session.remainingSeconds <= 60
    val optionLabels = if (isBangla) listOf("ক", "খ", "গ", "ঘ") else listOf("A", "B", "C", "D")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = session.exam.displayTitle(isBangla),
                        maxLines = 1,
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                actions = {
                    Surface(
                        color = if (isTimeUrgent) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = strings.timeRemaining,
                                tint = if (isTimeUrgent) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = BanglaDateUtils.formatTimer(session.remainingSeconds, isBangla),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isTimeUrgent) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Question Number Navigator Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                session.questions.forEachIndexed { idx, q ->
                    val answered = session.selectedAnswers.containsKey(q.id)
                    val isCurrent = idx == session.currentQuestionIndex
                    Surface(
                        shape = CircleShape,
                        color = when {
                            isCurrent -> MaterialTheme.colorScheme.primary
                            answered -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clickable { onNavigateQuestion(idx) }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = BanglaDateUtils.formatNumber(idx + 1, isBangla),
                                style = MaterialTheme.typography.labelLarge,
                                color = when {
                                    isCurrent -> MaterialTheme.colorScheme.onPrimary
                                    answered -> MaterialTheme.colorScheme.onTertiaryContainer
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }
                    }
                }
            }

            if (currentQuestion != null) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "${strings.questionLabel} ${BanglaDateUtils.formatNumber(session.currentQuestionIndex + 1, isBangla)} / ${BanglaDateUtils.formatNumber(session.questions.size, isBangla)}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = currentQuestion.displayQuestion(isBangla),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(18.dp)
                        )
                    }

                    val selectedIdx = session.selectedAnswers[currentQuestion.id]
                    currentQuestion.options.take(4).forEachIndexed { optIndex, optionText ->
                        val isSelected = selectedIdx == optIndex
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectOption(currentQuestion.id, optIndex) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSelectOption(currentQuestion.id, optIndex) }
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = "${optionLabels[optIndex]}. ",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = optionText,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Navigation & Submit Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { onNavigateQuestion(session.currentQuestionIndex - 1) },
                    enabled = session.currentQuestionIndex > 0,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text(strings.previousLabel)
                }

                if (session.currentQuestionIndex < session.questions.lastIndex) {
                    Button(
                        onClick = { onNavigateQuestion(session.currentQuestionIndex + 1) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(strings.nextLabel)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                } else {
                    Button(
                        onClick = { showConfirmSubmit = true },
                        enabled = !session.isSubmitting,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_exam_button")
                    ) {
                        if (session.isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.submitExam)
                        }
                    }
                }
            }

            if (session.currentQuestionIndex < session.questions.lastIndex) {
                OutlinedButton(
                    onClick = { showConfirmSubmit = true },
                    enabled = !session.isSubmitting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_exam_early_button")
                ) {
                    Text(strings.submitExam)
                }
            }
        }
    }

    if (showConfirmSubmit) {
        AlertDialog(
            onDismissRequest = { showConfirmSubmit = false },
            title = { Text(strings.confirmSubmitExamTitle) },
            text = {
                val answeredCount = session.selectedAnswers.size
                val totalCount = session.questions.size
                Text("${strings.confirmSubmitExamBody}\n(${BanglaDateUtils.formatNumber(answeredCount, isBangla)} / ${BanglaDateUtils.formatNumber(totalCount, isBangla)})")
            },
            confirmButton = {
                Button(onClick = {
                    showConfirmSubmit = false
                    onSubmit()
                }) { Text(strings.confirmLabel) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmSubmit = false }) { Text(strings.cancelLabel) }
            }
        )
    }

    if (showExitConfirm) {
        AlertDialog(
            onDismissRequest = { showExitConfirm = false },
            title = { Text(if (isBangla) "পরীক্ষা থেকে বের হবেন?" else "Exit Exam?") },
            text = {
                Text(if (isBangla) "বের হয়ে গেলে আপনার বর্তমান উত্তরগুলো সংরক্ষিত হবে না।" else "Exiting now will discard your current answers.")
            },
            confirmButton = {
                Button(onClick = {
                    showExitConfirm = false
                    onExitWithoutSubmitting()
                }) { Text(strings.confirmLabel) }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirm = false }) { Text(strings.cancelLabel) }
            }
        )
    }
}
