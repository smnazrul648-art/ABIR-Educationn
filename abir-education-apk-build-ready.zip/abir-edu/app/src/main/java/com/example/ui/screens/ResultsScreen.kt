package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.model.Exam
import com.example.model.ExamAttempt
import com.example.model.LeaderboardEntry
import com.example.model.McqQuestion
import com.example.model.UiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.LoadingStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AbirSuccessContainer
import com.example.ui.theme.AbirSuccessGreen
import com.example.util.BanglaDateUtils

@Composable
fun ResultsScreen(
    language: AppLanguage,
    myAttemptsState: UiState<List<ExamAttempt>>,
    publishedExams: List<Exam>,
    selectedLeaderboardExamId: String?,
    leaderboardState: UiState<List<LeaderboardEntry>>,
    onSelectLeaderboardExam: (String) -> Unit,
    onOpenAttemptReview: (ExamAttempt) -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(strings.historyTitle) },
                icon = { Icon(Icons.Default.History, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(strings.leaderboardTitle) },
                icon = { Icon(Icons.Default.EmojiEvents, contentDescription = null) }
            )
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (myAttemptsState) {
                    is UiState.Loading -> item { LoadingStateView(strings.loadingLabel) }
                    is UiState.Error -> item { ErrorRetryCard(myAttemptsState.message, strings.retryLabel) }
                    is UiState.Success -> {
                        val list = myAttemptsState.data
                        if (list.isEmpty()) {
                            item { EmptyStateCard(title = strings.noResultsFound) }
                        } else {
                            items(list, key = { it.id }) { attempt ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onOpenAttemptReview(attempt) },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = attempt.displayExamTitle(isBangla),
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            if (attempt.resultPublished) {
                                                StatusBadge(
                                                    text = "${BanglaDateUtils.formatNumber(attempt.score, isBangla)} / ${BanglaDateUtils.formatNumber(attempt.totalMarks, isBangla)}",
                                                    containerColor = AbirSuccessContainer,
                                                    contentColor = AbirSuccessGreen
                                                )
                                            } else {
                                                StatusBadge(text = if (isBangla) "অপেক্ষমাণ" else "Pending")
                                            }
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        if (attempt.resultPublished) {
                                            Text(
                                                text = if (isBangla) {
                                                    "সঠিক: ${BanglaDateUtils.toBanglaDigits(attempt.correctCount)} • ভুল: ${BanglaDateUtils.toBanglaDigits(attempt.wrongCount)} • বাদ: ${BanglaDateUtils.toBanglaDigits(attempt.skippedCount)}"
                                                } else {
                                                    "Correct: ${attempt.correctCount} • Wrong: ${attempt.wrongCount} • Skipped: ${attempt.skippedCount}"
                                                },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            Text(
                                                text = strings.resultPendingNotice,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = BanglaDateUtils.formatReadableDateTime(attempt.submittedAt, isBangla),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (publishedExams.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            publishedExams.forEach { exam ->
                                FilterChip(
                                    selected = selectedLeaderboardExamId == exam.id,
                                    onClick = { onSelectLeaderboardExam(exam.id) },
                                    label = { Text(exam.displayTitle(isBangla)) }
                                )
                            }
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = if (isBangla) {
                                    "গোপনীয়তা সুরক্ষিত: শুধুমাত্র প্রোফাইল থেকে সম্মতি দেওয়া শিক্ষার্থীদের নাম এখানে দেখানো হয়।"
                                } else {
                                    "Privacy Protected: Only students who opt in from Profile appear on the leaderboard."
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                when (leaderboardState) {
                    is UiState.Loading -> item { LoadingStateView(strings.loadingLabel) }
                    is UiState.Error -> item { ErrorRetryCard(leaderboardState.message, strings.retryLabel) }
                    is UiState.Success -> {
                        val entries = leaderboardState.data
                        if (entries.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    title = if (isBangla) "এই পরীক্ষার জন্য মেধা তালিকায় কোনো তথ্য নেই" else "No leaderboard entries for this exam yet"
                                )
                            }
                        } else {
                            itemsIndexed(entries, key = { _, item -> item.id }) { index, entry ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        StatusBadge(text = "#${BanglaDateUtils.formatNumber(index + 1, isBangla)}")
                                        Spacer(Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(entry.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                            Text(
                                                text = "${BanglaDateUtils.formatClassLabel(entry.classLevel, isBangla)} • ${BanglaDateUtils.formatTimer(entry.timeTakenSeconds, isBangla)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            text = "${BanglaDateUtils.formatNumber(entry.score, isBangla)}/${BanglaDateUtils.formatNumber(entry.totalMarks, isBangla)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamResultDetailScreen(
    attempt: ExamAttempt,
    questions: List<McqQuestion>,
    language: AppLanguage,
    onBack: () -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    val optionLabels = if (isBangla) listOf("ক", "খ", "গ", "ঘ") else listOf("A", "B", "C", "D")
    val totalQ = (attempt.correctCount + attempt.wrongCount + attempt.skippedCount).coerceAtLeast(1)
    val accuracyPercent = ((attempt.correctCount.toDouble() / totalQ) * 100.0).toInt()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(attempt.displayExamTitle(isBangla), maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = if (attempt.resultPublished) {
                                "${strings.scoreLabel}: ${BanglaDateUtils.formatNumber(attempt.score, isBangla)} / ${BanglaDateUtils.formatNumber(attempt.totalMarks, isBangla)}"
                            } else strings.resultPendingNotice,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (attempt.resultPublished) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "${strings.accuracyLabel}: ${BanglaDateUtils.formatNumber(accuracyPercent, isBangla)}% • ${if (isBangla) "সময়" else "Time"}: ${BanglaDateUtils.formatTimer(attempt.timeTakenSeconds, isBangla)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            if (attempt.resultPublished) {
                itemsIndexed(questions, key = { _, q -> q.id }) { idx, q ->
                    val chosen = attempt.selectedAnswers[q.id]?.toInt()
                    val isCorrect = chosen == q.correctOptionIndex
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(
                            1.dp,
                            if (isCorrect) AbirSuccessGreen else MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${strings.questionLabel} ${BanglaDateUtils.formatNumber(idx + 1, isBangla)}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (isCorrect) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = "Correct",
                                        tint = AbirSuccessGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(q.displayQuestion(isBangla), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            q.options.take(4).forEachIndexed { oIdx, opt ->
                                val marker = when {
                                    oIdx == q.correctOptionIndex -> "✅ "
                                    oIdx == chosen -> "❌ "
                                    else -> "• "
                                }
                                Text(
                                    text = "$marker${optionLabels[oIdx]}. $opt",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (oIdx == q.correctOptionIndex) FontWeight.Bold else FontWeight.Normal,
                                    color = when {
                                        oIdx == q.correctOptionIndex -> AbirSuccessGreen
                                        oIdx == chosen -> MaterialTheme.colorScheme.error
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                            val exp = q.displayExplanation(isBangla)
                            if (exp.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = "${strings.explanationLabel}: $exp",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
