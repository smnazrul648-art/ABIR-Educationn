package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class LessonType {
    TEXT, PDF, VIDEO;

    companion object {
        fun safeFrom(raw: String?): LessonType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: TEXT
    }
}

enum class AnnouncementPriority {
    NORMAL, IMPORTANT;

    companion object {
        fun safeFrom(raw: String?): AnnouncementPriority =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: NORMAL
    }
}

@Keep
@IgnoreExtraProperties
data class AdminAccount(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    @ServerTimestamp val initializedAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val classLevel: Int = 10,
    val preferredLanguage: String = "bn",
    val darkMode: Boolean = false,
    val leaderboardOptIn: Boolean = true,
    val suspended: Boolean = false,
    val fcmToken: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Bookmark(
    @DocumentId val id: String = "",
    val lessonId: String = "",
    val courseId: String = "",
    val subjectId: String = "",
    val classLevel: Int = 10,
    val titleBn: String = "",
    val titleEn: String = "",
    val lessonType: String = "TEXT",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class LessonProgress(
    @DocumentId val id: String = "",
    val lessonId: String = "",
    val courseId: String = "",
    val subjectId: String = "",
    val classLevel: Int = 10,
    val completed: Boolean = false,
    val progressPercent: Int = 0,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SchoolClass(
    @DocumentId val id: String = "",
    val level: Int = 1,
    val nameBn: String = "",
    val nameEn: String = "",
    val descriptionBn: String? = null,
    val descriptionEn: String? = null,
    val published: Boolean = true,
    val order: Int = 1,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayName(isBangla: Boolean): String = if (isBangla) nameBn.ifBlank { nameEn } else nameEn.ifBlank { nameBn }
    fun displayDesc(isBangla: Boolean): String = if (isBangla) descriptionBn.orEmpty() else descriptionEn.orEmpty()
}

@Keep
@IgnoreExtraProperties
data class Subject(
    @DocumentId val id: String = "",
    val classLevel: Int = 10,
    val nameBn: String = "",
    val nameEn: String = "",
    val iconName: String = "MenuBook",
    val colorHex: String = "#1565C0",
    val published: Boolean = true,
    val order: Int = 1,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayName(isBangla: Boolean): String = if (isBangla) nameBn.ifBlank { nameEn } else nameEn.ifBlank { nameBn }
}

@Keep
@IgnoreExtraProperties
data class Course(
    @DocumentId val id: String = "",
    val classLevel: Int = 10,
    val subjectId: String = "",
    val subjectNameBn: String = "",
    val titleBn: String = "",
    val titleEn: String = "",
    val descriptionBn: String? = null,
    val descriptionEn: String? = null,
    val instructorName: String = "",
    val lessonCount: Int = 0,
    val published: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayTitle(isBangla: Boolean): String = if (isBangla) titleBn.ifBlank { titleEn } else titleEn.ifBlank { titleBn }
    fun displayDesc(isBangla: Boolean): String = if (isBangla) descriptionBn.orEmpty() else descriptionEn.orEmpty()
}

@Keep
@IgnoreExtraProperties
data class Chapter(
    @DocumentId val id: String = "",
    val courseId: String = "",
    val classLevel: Int = 10,
    val titleBn: String = "",
    val titleEn: String = "",
    val order: Int = 1,
    val published: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayTitle(isBangla: Boolean): String = if (isBangla) titleBn.ifBlank { titleEn } else titleEn.ifBlank { titleBn }
}

@Keep
@IgnoreExtraProperties
data class Lesson(
    @DocumentId val id: String = "",
    val courseId: String = "",
    val chapterId: String = "",
    val subjectId: String = "",
    val classLevel: Int = 10,
    val titleBn: String = "",
    val titleEn: String = "",
    val contentBn: String = "",
    val contentEn: String = "",
    val lessonType: String = "TEXT",
    val pdfUrl: String? = null,
    val pdfStoragePath: String? = null,
    val videoUrl: String? = null,
    val durationMinutes: Int = 10,
    val order: Int = 1,
    val published: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayTitle(isBangla: Boolean): String = if (isBangla) titleBn.ifBlank { titleEn } else titleEn.ifBlank { titleBn }
    fun displayContent(isBangla: Boolean): String = if (isBangla) contentBn.ifBlank { contentEn } else contentEn.ifBlank { contentBn }
    fun parsedType(): LessonType = LessonType.safeFrom(lessonType)
}

@Keep
@IgnoreExtraProperties
data class Exam(
    @DocumentId val id: String = "",
    val classLevel: Int = 10,
    val subjectId: String = "",
    val subjectNameBn: String = "",
    val titleBn: String = "",
    val titleEn: String = "",
    val descriptionBn: String? = null,
    val durationMinutes: Int = 20,
    val totalMarks: Double = 10.0,
    val marksPerQuestion: Double = 1.0,
    val negativeMarkPerWrong: Double = 0.25,
    val questionCount: Int = 0,
    val published: Boolean = true,
    val resultsPublished: Boolean = true,
    val allowMultipleAttempts: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayTitle(isBangla: Boolean): String = if (isBangla) titleBn.ifBlank { titleEn } else titleEn.ifBlank { titleBn }
}

@Keep
@IgnoreExtraProperties
data class McqQuestion(
    @DocumentId val id: String = "",
    val examId: String = "",
    val examPublished: Boolean = true,
    val order: Int = 1,
    val questionBn: String = "",
    val questionEn: String = "",
    val options: List<String> = listOf("", "", "", ""),
    val correctOptionIndex: Int = 0,
    val explanationBn: String = "",
    val explanationEn: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayQuestion(isBangla: Boolean): String = if (isBangla) questionBn.ifBlank { questionEn } else questionEn.ifBlank { questionBn }
    fun displayExplanation(isBangla: Boolean): String = if (isBangla) explanationBn.ifBlank { explanationEn } else explanationEn.ifBlank { explanationBn }
}

@Keep
@IgnoreExtraProperties
data class ExamAttempt(
    @DocumentId val id: String = "",
    val userId: String = "",
    val studentDisplayName: String = "",
    val classLevel: Int = 10,
    val examId: String = "",
    val examTitleBn: String = "",
    val examTitleEn: String = "",
    val selectedAnswers: Map<String, Long> = emptyMap(),
    val score: Double = 0.0,
    val totalMarks: Double = 0.0,
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val skippedCount: Int = 0,
    val timeTakenSeconds: Int = 0,
    val autoSubmitted: Boolean = false,
    val resultPublished: Boolean = true,
    val leaderboardVisible: Boolean = true,
    @ServerTimestamp val submittedAt: Timestamp? = null
) {
    fun displayExamTitle(isBangla: Boolean): String = if (isBangla) examTitleBn.ifBlank { examTitleEn } else examTitleEn.ifBlank { examTitleBn }
}

@Keep
@IgnoreExtraProperties
data class LeaderboardEntry(
    @DocumentId val id: String = "",
    val examId: String = "",
    val userId: String = "",
    val displayName: String = "",
    val classLevel: Int = 10,
    val score: Double = 0.0,
    val totalMarks: Double = 0.0,
    val timeTakenSeconds: Int = 0,
    val publicVisible: Boolean = true,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Announcement(
    @DocumentId val id: String = "",
    val titleBn: String = "",
    val titleEn: String = "",
    val bodyBn: String = "",
    val bodyEn: String = "",
    val targetClassLevel: Int = 0,
    val priority: String = "NORMAL",
    val published: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun displayTitle(isBangla: Boolean): String = if (isBangla) titleBn.ifBlank { titleEn } else titleEn.ifBlank { titleBn }
    fun displayBody(isBangla: Boolean): String = if (isBangla) bodyBn.ifBlank { bodyEn } else bodyEn.ifBlank { bodyBn }
    fun parsedPriority(): AnnouncementPriority = AnnouncementPriority.safeFrom(priority)
}

@Keep
@IgnoreExtraProperties
data class AppConfig(
    @DocumentId val id: String = "",
    val latestVersionCode: Int = 1,
    val latestVersionName: String = "1.0.0",
    val updateNotesBn: String = "সর্বশেষ সংস্করণ চলছে।",
    val updateNotesEn: String = "You are on the latest version.",
    val supportEmail: String = "smnazrul648@gmail.com",
    val supportPhone: String = "+880 1700-000000",
    val privacyPolicyBn: String = "আবীর এডুকেশন শিক্ষার্থীদের নাম, ইমেইল, প্রোফাইল ছবি ও শ্রেণির তথ্য শুধুমাত্র শিক্ষামূলক সেবা প্রদানের জন্য নিরাপদ ফায়ারবেস ক্লাউডে সংরক্ষণ করে। কোনো ব্যক্তিগত তথ্য তৃতীয় পক্ষের সাথে শেয়ার করা হয় না।",
    val privacyPolicyEn: String = "ABIR Education stores student name, email, photo, and class selection securely in Firebase solely to deliver educational courses, offline notes, and exam results. Personal data is never shared with third parties.",
    val termsBn: String = "এই অ্যাপের সকল পাঠ্যনোট, PDF ও প্রশ্নপত্র শুধুমাত্র শিক্ষার্থীদের ব্যক্তিগত পড়াশোনার জন্য। অননুমোদিত কপি বা বাণিজ্যিক ব্যবহার নিষিদ্ধ।",
    val termsEn: String = "All lessons, PDFs, and exam materials are provided exclusively for personal educational use. Unauthorized redistribution or commercial misuse is prohibited.",
    @ServerTimestamp val updatedAt: Timestamp? = null
)
