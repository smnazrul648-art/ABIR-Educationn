package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ExamAttempt
import com.example.model.UserProfile
import com.example.ui.components.StatusBadge
import com.example.util.BanglaDateUtils
import com.example.viewmodel.AdminViewModel

@Composable
fun AdminStudentsTab(
    adminViewModel: AdminViewModel,
    students: List<UserProfile>,
    attempts: List<ExamAttempt>,
    isBangla: Boolean
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = if (isBangla) "নিবন্ধিত শিক্ষার্থী (${students.size})" else "Registered Students (${students.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(students, key = { it.uid }) { student ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(student.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(student.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        StatusBadge(text = BanglaDateUtils.formatClassLabel(student.classLevel, isBangla))
                    }
                    OutlinedButton(
                        onClick = { adminViewModel.toggleStudentSuspension(student.uid, !student.suspended) }
                    ) {
                        Text(
                            if (student.suspended) (if (isBangla) "সক্রিয় করুন" else "Unsuspend")
                            else (if (isBangla) "স্থগিত করুন" else "Suspend")
                        )
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            Text(
                text = if (isBangla) "পরীক্ষার ফলাফল ব্যবস্থাপনা (${attempts.size})" else "Exam Attempts & Publishing (${attempts.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(attempts, key = { it.id }) { attempt ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(attempt.studentDisplayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(attempt.displayExamTitle(isBangla), style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "${BanglaDateUtils.formatNumber(attempt.score, isBangla)} / ${BanglaDateUtils.formatNumber(attempt.totalMarks, isBangla)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (attempt.resultPublished) "Published" else "Hidden",
                            style = MaterialTheme.typography.labelSmall
                        )
                        Switch(
                            checked = attempt.resultPublished,
                            onCheckedChange = { adminViewModel.toggleAttemptPublished(attempt.id, it) }
                        )
                    }
                }
            }
        }
    }
}
