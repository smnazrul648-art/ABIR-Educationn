package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AdminAccount
import com.example.model.Announcement
import com.example.model.AppConfig
import com.example.model.Chapter
import com.example.model.Course
import com.example.model.Exam
import com.example.model.ExamAttempt
import com.example.model.Lesson
import com.example.model.McqQuestion
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.repository.AdminRepository
import com.example.util.extractRootFirestoreMessage
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class AdminViewModel(
    private val adminRepository: AdminRepository,
    private val currentUserId: String
) : ViewModel() {

    val adminAccountState: StateFlow<UiState<AdminAccount?>> = adminRepository.observeAdminAccount(currentUserId)
        .toUiState("অ্যাডমিন তথ্য লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val isAdminInitializedFlow: Flow<Boolean> = adminAccountState
        .map { it is UiState.Success && it.data != null }

    val allClasses: StateFlow<List<SchoolClass>> = gatedAdminStream(
        adminRepository.observeAllClasses(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allSubjects: StateFlow<List<Subject>> = gatedAdminStream(
        adminRepository.observeAllSubjects(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allCourses: StateFlow<List<Course>> = gatedAdminStream(
        adminRepository.observeAllCourses(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allChapters: StateFlow<List<Chapter>> = gatedAdminStream(
        adminRepository.observeAllChapters(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allLessons: StateFlow<List<Lesson>> = gatedAdminStream(
        adminRepository.observeAllLessons(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allExams: StateFlow<List<Exam>> = gatedAdminStream(
        adminRepository.observeAllExams(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allStudents: StateFlow<List<UserProfile>> = gatedAdminStream(
        adminRepository.observeAllStudents(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allAttempts: StateFlow<List<ExamAttempt>> = gatedAdminStream(
        adminRepository.observeAllAttempts(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val allAnnouncements: StateFlow<List<Announcement>> = gatedAdminStream(
        adminRepository.observeAllAnnouncements(), emptyList()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _selectedExamIdForQuestions = MutableStateFlow<String?>(null)
    val selectedExamIdForQuestions: StateFlow<String?> = _selectedExamIdForQuestions.asStateFlow()

    val selectedExamQuestions: StateFlow<List<McqQuestion>> = _selectedExamIdForQuestions
        .flatMapLatest { examId ->
            if (examId.isNullOrBlank()) flowOf(emptyList())
            else adminRepository.observeAllQuestionsForExam(examId)
                .catch { e ->
                    if (e is CancellationException) throw e
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val events = _events.asSharedFlow()

    fun selectExamForQuestions(examId: String?) {
        _selectedExamIdForQuestions.value = examId
    }

    fun initializeFirstAdmin() {
        runAction("অ্যাডমিন অ্যাকাউন্ট সক্রিয় হয়েছে!") {
            adminRepository.initializeFirstAdmin()
        }
    }

    fun seedClasses1To12() {
        runAction("প্রথম থেকে দ্বাদশ শ্রেণি সফলভাবে যোগ করা হয়েছে!") {
            adminRepository.seedClasses1To12()
        }
    }

    fun saveClass(schoolClass: SchoolClass) = runAction("শ্রেণি সংরক্ষিত হয়েছে") {
        adminRepository.saveClass(schoolClass)
    }

    fun deleteClass(id: String) = runAction("শ্রেণি মুছে ফেলা হয়েছে") {
        adminRepository.deleteClass(id)
    }

    fun saveSubject(subject: Subject) = runAction("বিষয় সংরক্ষিত হয়েছে") {
        adminRepository.saveSubject(subject)
    }

    fun deleteSubject(id: String) = runAction("বিষয় মুছে ফেলা হয়েছে") {
        adminRepository.deleteSubject(id)
    }

    fun saveCourse(course: Course) = runAction("কোর্স সংরক্ষিত হয়েছে") {
        adminRepository.saveCourse(course)
    }

    fun deleteCourse(id: String) = runAction("কোর্স মুছে ফেলা হয়েছে") {
        adminRepository.deleteCourse(id)
    }

    fun saveChapter(chapter: Chapter) = runAction("অধ্যায় সংরক্ষিত হয়েছে") {
        adminRepository.saveChapter(chapter)
    }

    fun deleteChapter(id: String) = runAction("অধ্যায় মুছে ফেলা হয়েছে") {
        adminRepository.deleteChapter(id)
    }

    fun uploadPdfAndSaveLesson(
        context: Context,
        pdfUri: Uri?,
        lesson: Lesson
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            var finalLesson = lesson
            if (pdfUri != null) {
                val uploadRes = adminRepository.uploadPdfToStorage(
                    context = context,
                    pdfUri = pdfUri,
                    classLevel = lesson.classLevel,
                    fileNamePrefix = "note_${lesson.courseId.take(12)}"
                )
                if (uploadRes.isFailure) {
                    _isBusy.value = false
                    val msg = uploadRes.exceptionOrNull()?.localizedMessage ?: "PDF আপলোড ব্যর্থ হয়েছে"
                    _events.tryEmit("Storage আপলোড ব্যর্থ: $msg (Firebase Console থেকে Storage চালু করুন অথবা সরাসরি PDF লিংক দিন)")
                    return@launch
                }
                val (url, storagePath) = uploadRes.getOrThrow()
                finalLesson = lesson.copy(pdfUrl = url, pdfStoragePath = storagePath)
            }
            val res = adminRepository.saveLesson(finalLesson)
            _isBusy.value = false
            emitResult(res, "লেসন সংরক্ষিত হয়েছে")
        }
    }

    fun deleteLesson(id: String) = runAction("লেসন মুছে ফেলা হয়েছে") {
        adminRepository.deleteLesson(id)
    }

    fun saveExam(exam: Exam, onSavedId: (String) -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = adminRepository.saveExam(exam)
            _isBusy.value = false
            res.onSuccess { id ->
                _events.tryEmit("পরীক্ষা সংরক্ষিত হয়েছে")
                onSavedId(id)
            }.onFailure { err ->
                _events.tryEmit(extractRootFirestoreMessage(err, "সংরক্ষণ ব্যর্থ হয়েছে"))
            }
        }
    }

    fun deleteExam(id: String) = runAction("পরীক্ষা মুছে ফেলা হয়েছে") {
        adminRepository.deleteExam(id)
    }

    fun saveMcqQuestion(exam: Exam, question: McqQuestion) = runAction("MCQ প্রশ্ন সংরক্ষিত হয়েছে") {
        adminRepository.saveMcqQuestion(exam, question)
    }

    fun deleteMcqQuestion(examId: String, questionId: String) = runAction("প্রশ্ন মুছে ফেলা হয়েছে") {
        adminRepository.deleteMcqQuestion(examId, questionId)
    }

    fun saveAnnouncement(announcement: Announcement) = runAction("ঘোষণা প্রকাশিত হয়েছে") {
        adminRepository.saveAnnouncement(announcement)
    }

    fun deleteAnnouncement(id: String) = runAction("ঘোষণা মুছে ফেলা হয়েছে") {
        adminRepository.deleteAnnouncement(id)
    }

    fun toggleStudentSuspension(userId: String, suspend: Boolean) = runAction(
        if (suspend) "শিক্ষার্থীর অ্যাকাউন্ট স্থগিত করা হয়েছে" else "অ্যাকাউন্ট পুনরায় সক্রিয় করা হয়েছে"
    ) {
        adminRepository.toggleStudentSuspension(userId, suspend)
    }

    fun toggleAttemptPublished(attemptId: String, published: Boolean) = runAction(
        if (published) "ফলাফল প্রকাশিত হয়েছে" else "ফলাফল অপ্রকাশিত রাখা হয়েছে"
    ) {
        adminRepository.toggleAttemptPublished(attemptId, published)
    }

    fun saveAppConfig(config: AppConfig) = runAction("অ্যাপ কনফিগারেশন আপডেট হয়েছে") {
        adminRepository.saveAppConfig(config)
    }

    private fun runAction(successMessage: String, block: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = block()
            _isBusy.value = false
            emitResult(res, successMessage)
        }
    }

    private fun emitResult(res: Result<Unit>, successMessage: String) {
        if (res.isSuccess) {
            _events.tryEmit(successMessage)
        } else {
            val err = res.exceptionOrNull()
            _events.tryEmit(
                if (err != null) extractRootFirestoreMessage(err, "কাজটি সম্পন্ন করা যায়নি")
                else "কাজটি সম্পন্ন করা যায়নি"
            )
        }
    }

    private fun <T> gatedAdminStream(source: Flow<T>, empty: T): Flow<T> =
        isAdminInitializedFlow.flatMapLatest { initialized ->
            if (!initialized) flowOf(empty)
            else source.catch { e ->
                if (e is CancellationException) throw e
                Log.w(TAG, "Admin stream error: ${e.message}")
                emit(empty)
            }
        }

    private fun <T> Flow<T>.toUiState(fallback: String): Flow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                emit(UiState.Error(extractRootFirestoreMessage(root, fallback)))
            }

    private companion object {
        const val TAG = "AdminViewModel"
    }
}
