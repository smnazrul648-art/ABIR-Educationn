package com.example.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OfflineNoteDao {
    @Query("SELECT * FROM offline_notes ORDER BY savedAtMillis DESC")
    fun observeAll(): Flow<List<OfflineNoteEntity>>

    @Query("SELECT * FROM offline_notes WHERE lessonId = :lessonId LIMIT 1")
    suspend fun getByLessonId(lessonId: String): OfflineNoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: OfflineNoteEntity)

    @Query("DELETE FROM offline_notes WHERE lessonId = :lessonId")
    suspend fun deleteByLessonId(lessonId: String)
}
