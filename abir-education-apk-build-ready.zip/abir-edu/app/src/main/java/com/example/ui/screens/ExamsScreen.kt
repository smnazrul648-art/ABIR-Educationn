package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.model.Exam
import com.example.model.ExamAttempt
import com.example.model.UiState
import com.example.ui.components.ClassFilterRow
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.LoadingStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AbirWarningAmber
import com.example.ui.theme.AbirWarningContainer
import com.example.util.BanglaDateUtils

@Composable
fun ExamsScreen(
    language: AppLanguage,
    selectedClassFilter: Int?,
    examsState: UiState<List<Exam>>,
    myAttemptsState: UiState<List<ExamAttempt>>,
    isLoadingQuestions: Boolean,
    onSelectClass: (Int?) -> Unit,
    onStartExam: (Exam) -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    val attempts = (myAttemptsState as? UiState.Success)?.data.orEmpty()
    val attemptedExamIds = attempts.map { it.examId }.toSet()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ClassFilterRow(
                selectedClass = selectedClassFilter,
                allLabel = strings.allClasses,
                isBangla = isBangla,
                includeAllOption = true,
                onSelect = onSelectClass
            )
        }

        if (isLoadingQuestions) {
            item { LoadingStateView(if (isBangla) "প্রশ্নপত্র প্রস্তুত হচ্ছে..." else "Preparing questions...") }
        }

        when (examsState) {
            is UiState.Loading -> item { LoadingStateView(strings.loadingLabel) }
            is UiState.Error -> item { ErrorRetryCard(examsState.message, strings.retryLabel) }
            is UiState.Success -> {
                val filtered = examsState.data.filter {
                    selectedClassFilter == null || it.classLevel == selectedClassFilter
                }
                if (filtered.isEmpty()) {
                    item { EmptyStateCard(title = strings.noExamsFound) }
                } else {
                    items(filtered, key = { it.id }) { exam ->
                        val hasAttempted = exam.id in attemptedExamIds
                        val blockedDuplicate = hasAttempted && !exam.allowMultipleAttempts
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        StatusBadge(text = BanglaDateUtils.formatClassLabel(exam.classLevel, isBangla))
                                        StatusBadge(
                                            text = exam.subjectNameBn,
                                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    }
                                    if (hasAttempted) {
                                        StatusBadge(
                                            text = strings.alreadySubmitted,
                                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                                            showCheck = true
                                        )
                                    }
                                }

                                Spacer(Modifier.height(10.dp))
                                Text(
                                    text = exam.displayTitle(isBangla),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (!exam.descriptionBn.isNullOrBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = exam.descriptionBn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Schedule,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = "${BanglaDateUtils.formatNumber(exam.durationMinutes, isBangla)} ${strings.minutesShort}",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Quiz,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = "${BanglaDateUtils.formatNumber(exam.questionCount, isBangla)} ${if (isBangla) "টি প্রশ্ন" else "MCQs"} • ${BanglaDateUtils.formatNumber(exam.totalMarks, isBangla)} ${if (isBangla) "নম্বর" else "marks"}",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                }

                                if (exam.negativeMarkPerWrong > 0.0) {
                                    Spacer(Modifier.height(6.dp))
                                    StatusBadge(
                                        text = "${strings.negativeMarksLabel}: -${BanglaDateUtils.formatNumber(exam.negativeMarkPerWrong, isBangla)}",
                                        containerColor = AbirWarningContainer,
                                        contentColor = AbirWarningAmber
                                    )
                                }

                                Spacer(Modifier.height(14.dp))
                                Button(
                                    onClick = { onStartExam(exam) },
                                    enabled = !blockedDuplicate && !isLoadingQuestions,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("start_exam_${exam.id}")
                                ) {
                                    if (isLoadingQuestions) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            when {
                                                blockedDuplicate -> strings.alreadySubmitted
                                                hasAttempted -> strings.retakeExam
                                                else -> strings.startExam
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
