package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.model.AppConfig
import com.example.model.UiState
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.LoadingStateView
import com.example.util.BanglaDateUtils
import com.example.viewmodel.AdminViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    adminViewModel: AdminViewModel,
    appConfig: AppConfig,
    language: AppLanguage,
    onBack: () -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    val adminState by adminViewModel.adminAccountState.collectAsStateWithLifecycle()
    val isBusy by adminViewModel.isBusy.collectAsStateWithLifecycle()

    val classes by adminViewModel.allClasses.collectAsStateWithLifecycle()
    val subjects by adminViewModel.allSubjects.collectAsStateWithLifecycle()
    val courses by adminViewModel.allCourses.collectAsStateWithLifecycle()
    val chapters by adminViewModel.allChapters.collectAsStateWithLifecycle()
    val lessons by adminViewModel.allLessons.collectAsStateWithLifecycle()
    val exams by adminViewModel.allExams.collectAsStateWithLifecycle()
    val students by adminViewModel.allStudents.collectAsStateWithLifecycle()
    val attempts by adminViewModel.allAttempts.collectAsStateWithLifecycle()
    val announcements by adminViewModel.allAnnouncements.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings.adminPanelTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isBusy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            when (val state = adminState) {
                is UiState.Loading -> LoadingStateView(strings.loadingLabel)
                is UiState.Error -> {
                    Column(modifier = Modifier.padding(16.dp)) {
                        ErrorRetryCard(state.message, strings.retryLabel)
                    }
                }
                is UiState.Success -> {
                    val adminAccount = state.data
                    if (adminAccount == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        text = strings.adminInitTitle,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = if (isBangla) {
                                            "নিরাপত্তা নিয়ম অনুযায়ী প্রথমবার শুধুমাত্র ভেরিফায়েড মালিকের Google ইমেইল দিয়ে অ্যাডমিন অ্যাকাউন্ট সক্রিয় করতে হবে।"
                                        } else {
                                            "Initialize your single owner admin document verified by Firestore backend security rules."
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(18.dp))
                                    Button(
                                        onClick = { adminViewModel.initializeFirstAdmin() },
                                        enabled = !isBusy,
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("init_admin_button")
                                    ) {
                                        Icon(Icons.Default.VerifiedUser, contentDescription = null)
                                        Spacer(Modifier.width(8.dp))
                                        Text(strings.adminInitButton)
                                    }
                                }
                            }
                        }
                    } else {
                        val tabs = if (isBangla) {
                            listOf("পরিসংখ্যান", "একাডেমিক", "পরীক্ষা ও MCQ", "শিক্ষার্থী ও ফল", "নোটিশ ও সেটিংস")
                        } else {
                            listOf("Stats", "Academic", "Exams & MCQ", "Students", "Notices & Config")
                        }

                        ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 12.dp) {
                            tabs.forEachIndexed { idx, label ->
                                Tab(
                                    selected = selectedTab == idx,
                                    onClick = { selectedTab = idx },
                                    text = { Text(label) }
                                )
                            }
                        }

                        when (selectedTab) {
                            0 -> AdminOverviewTab(
                                isBangla = isBangla,
                                studentCount = students.size,
                                classCount = classes.size,
                                courseCount = courses.size,
                                examCount = exams.size,
                                attemptCount = attempts.size,
                                avgScorePercent = if (attempts.isEmpty()) 0 else {
                                    val avg = attempts.mapNotNull {
                                        if (it.totalMarks > 0) (it.score / it.totalMarks) * 100.0 else null
                                    }.average()
                                    if (avg.isNaN()) 0 else avg.toInt()
                                },
                                onSeedClasses = { adminViewModel.seedClasses1To12() }
                            )
                            1 -> AdminAcademicTab(
                                adminViewModel = adminViewModel,
                                classes = classes,
                                subjects = subjects,
                                courses = courses,
                                chapters = chapters,
                                lessons = lessons,
                                isBangla = isBangla
                            )
                            2 -> AdminExamTab(
                                adminViewModel = adminViewModel,
                                subjects = subjects,
                                exams = exams,
                                isBangla = isBangla
                            )
                            3 -> AdminStudentsTab(
                                adminViewModel = adminViewModel,
                                students = students,
                                attempts = attempts,
                                isBangla = isBangla
                            )
                            4 -> AdminSettingsTab(
                                adminViewModel = adminViewModel,
                                announcements = announcements,
                                appConfig = appConfig,
                                isBangla = isBangla
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminOverviewTab(
    isBangla: Boolean,
    studentCount: Int,
    classCount: Int,
    courseCount: Int,
    examCount: Int,
    attemptCount: Int,
    avgScorePercent: Int,
    onSeedClasses: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AdminStatCard(
                    title = if (isBangla) "শিক্ষার্থী" else "Students",
                    value = BanglaDateUtils.formatNumber(studentCount, isBangla),
                    icon = Icons.Default.People,
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = if (isBangla) "কোর্স" else "Courses",
                    value = BanglaDateUtils.formatNumber(courseCount, isBangla),
                    icon = Icons.Default.MenuBook,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AdminStatCard(
                    title = if (isBangla) "পরীক্ষা" else "Exams",
                    value = BanglaDateUtils.formatNumber(examCount, isBangla),
                    icon = Icons.Default.Quiz,
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = if (isBangla) "গড় স্কোর" else "Avg Score",
                    value = "${BanglaDateUtils.formatNumber(avgScorePercent, isBangla)}%",
                    icon = Icons.Default.VerifiedUser,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBangla) "মোট অংশগ্রহণকৃত পরীক্ষা: ${BanglaDateUtils.toBanglaDigits(attemptCount)} • সক্রিয় শ্রেণি: ${BanglaDateUtils.toBanglaDigits(classCount)}"
                        else "Total Exam Attempts: $attemptCount • Configured Classes: $classCount",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = onSeedClasses,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isBangla) "শ্রেণি ১ - ১২ অটো সেটআপ করুন" else "Initialize Classes 1 to 12")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
