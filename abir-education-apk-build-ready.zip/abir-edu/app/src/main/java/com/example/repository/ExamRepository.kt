package com.example.repository

import com.example.model.Exam
import com.example.model.ExamAttempt
import com.example.model.LeaderboardEntry
import com.example.model.McqQuestion
import com.example.model.UserProfile
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.math.round

class ExamRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing exams.")
    }

    fun observePublishedExams(): Flow<List<Exam>> =
        db.collection("exams")
            .whereEqualTo("published", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(Exam::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    suspend fun getExamQuestions(examId: String): Result<List<McqQuestion>> {
        val path = "exams/$examId/questions"
        return try {
            requireUserId()
            val snap = db.collection("exams").document(examId)
                .collection("questions")
                .whereEqualTo("examPublished", true)
                .get()
                .await()
            val list = snap.toObjects(McqQuestion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { it.order }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    fun observeMyAttempts(userId: String): Flow<List<ExamAttempt>> =
        db.collection("exam_attempts")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(ExamAttempt::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.submittedAt?.seconds ?: 0L }
            }

    fun observeLeaderboard(examId: String): Flow<List<LeaderboardEntry>> =
        db.collection("leaderboard")
            .whereEqualTo("examId", examId)
            .whereEqualTo("publicVisible", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(LeaderboardEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(
                        compareByDescending<LeaderboardEntry> { it.score }
                            .thenBy { it.timeTakenSeconds }
                    )
            }

    suspend fun submitExamAttempt(
        exam: Exam,
        questions: List<McqQuestion>,
        selectedAnswers: Map<String, Int>,
        profile: UserProfile,
        timeTakenSeconds: Int,
        autoSubmitted: Boolean
    ): Result<ExamAttempt> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        val attemptDocId = if (exam.allowMultipleAttempts) {
            "${exam.id}_${uid}_${System.currentTimeMillis()}"
        } else {
            "${exam.id}_${uid}"
        }
        val attemptPath = "exam_attempts/$attemptDocId"

        return try {
            if (!exam.allowMultipleAttempts) {
                val existingAttempt = db.collection("exam_attempts").document(attemptDocId).get().await()
                if (existingAttempt.exists()) {
                    return Result.failure(IllegalStateException("এই পরীক্ষায় আপনি ইতিমধ্যে অংশগ্রহণ করেছেন।"))
                }
            }

            var correct = 0
            var wrong = 0
            var skipped = 0
            val answerMap = mutableMapOf<String, Long>()

            for (q in questions) {
                val selected = selectedAnswers[q.id]
                if (selected == null || selected !in 0..3) {
                    skipped++
                } else {
                    answerMap[q.id] = selected.toLong()
                    if (selected == q.correctOptionIndex) {
                        correct++
                    } else {
                        wrong++
                    }
                }
            }

            val rawScore = (correct * exam.marksPerQuestion) - (wrong * exam.negativeMarkPerWrong)
            val roundedScore = round(rawScore * 100.0) / 100.0
            val computedTotalMarks = if (exam.totalMarks > 0.0) exam.totalMarks else (questions.size * exam.marksPerQuestion)

            val attemptPayload = mapOf(
                "userId" to uid,
                "studentDisplayName" to profile.name.ifBlank { "Student" }.take(100),
                "classLevel" to profile.classLevel.coerceIn(1, 12),
                "examId" to exam.id,
                "examTitleBn" to exam.titleBn.ifBlank { exam.titleEn }.take(200),
                "examTitleEn" to exam.titleEn.ifBlank { exam.titleBn }.take(200),
                "selectedAnswers" to answerMap,
                "score" to roundedScore,
                "totalMarks" to computedTotalMarks,
                "correctCount" to correct,
                "wrongCount" to wrong,
                "skippedCount" to skipped,
                "timeTakenSeconds" to timeTakenSeconds.coerceAtLeast(0),
                "autoSubmitted" to autoSubmitted,
                "resultPublished" to exam.resultsPublished,
                "leaderboardVisible" to profile.leaderboardOptIn,
                "submittedAt" to FieldValue.serverTimestamp()
            )

            db.collection("exam_attempts").document(attemptDocId).set(attemptPayload).await()

            val leaderboardDocId = "${exam.id}_${uid}"
            val lbRef = db.collection("leaderboard").document(leaderboardDocId)
            if (profile.leaderboardOptIn && exam.resultsPublished) {
                val lbPayload = mapOf(
                    "examId" to exam.id,
                    "userId" to uid,
                    "displayName" to profile.name.ifBlank { "Student" }.take(100),
                    "classLevel" to profile.classLevel.coerceIn(1, 12),
                    "score" to roundedScore,
                    "totalMarks" to computedTotalMarks,
                    "timeTakenSeconds" to timeTakenSeconds.coerceAtLeast(0),
                    "publicVisible" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                lbRef.set(lbPayload).await()
            }

            val createdAttempt = ExamAttempt(
                id = attemptDocId,
                userId = uid,
                studentDisplayName = profile.name,
                classLevel = profile.classLevel,
                examId = exam.id,
                examTitleBn = exam.titleBn,
                examTitleEn = exam.titleEn,
                selectedAnswers = answerMap,
                score = roundedScore,
                totalMarks = computedTotalMarks,
                correctCount = correct,
                wrongCount = wrong,
                skippedCount = skipped,
                timeTakenSeconds = timeTakenSeconds,
                autoSubmitted = autoSubmitted,
                resultPublished = exam.resultsPublished,
                leaderboardVisible = profile.leaderboardOptIn
            )
            Result.success(createdAttempt)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, attemptPath)
            Result.failure(e)
        }
    }
}
