package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.Exam
import com.example.model.ExamAttempt
import com.example.model.LeaderboardEntry
import com.example.model.McqQuestion
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.repository.ExamRepository
import com.example.util.extractRootFirestoreMessage
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ActiveExamSession(
    val exam: Exam,
    val questions: List<McqQuestion>,
    val currentQuestionIndex: Int = 0,
    val selectedAnswers: Map<String, Int> = emptyMap(),
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val isSubmitting: Boolean = false
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class ExamViewModel(
    private val examRepository: ExamRepository,
    private val currentUserId: String
) : ViewModel() {

    val publishedExamsState: StateFlow<UiState<List<Exam>>> = examRepository.observePublishedExams()
        .toUiState("পরীক্ষার তালিকা লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val myAttemptsState: StateFlow<UiState<List<ExamAttempt>>> = examRepository.observeMyAttempts(currentUserId)
        .toUiState("পরীক্ষার ইতিহাস লোড হয়নি")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _selectedLeaderboardExamId = MutableStateFlow<String?>(null)
    val selectedLeaderboardExamId: StateFlow<String?> = _selectedLeaderboardExamId.asStateFlow()

    val leaderboardState: StateFlow<UiState<List<LeaderboardEntry>>> = _selectedLeaderboardExamId
        .flatMapLatest { examId ->
            if (examId.isNullOrBlank()) flowOf(UiState.Success(emptyList()))
            else examRepository.observeLeaderboard(examId)
                .toUiState("লিডারবোর্ড লোড হয়নি")
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Success(emptyList()))

    private val _activeSession = MutableStateFlow<ActiveExamSession?>(null)
    val activeSession: StateFlow<ActiveExamSession?> = _activeSession.asStateFlow()

    private val _lastSubmittedAttempt = MutableStateFlow<ExamAttempt?>(null)
    val lastSubmittedAttempt: StateFlow<ExamAttempt?> = _lastSubmittedAttempt.asStateFlow()

    private val _reviewQuestions = MutableStateFlow<List<McqQuestion>>(emptyList())
    val reviewQuestions: StateFlow<List<McqQuestion>> = _reviewQuestions.asStateFlow()

    private val _isLoadingQuestions = MutableStateFlow(false)
    val isLoadingQuestions: StateFlow<Boolean> = _isLoadingQuestions.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events = _events.asSharedFlow()

    private var timerJob: Job? = null

    fun selectLeaderboardExam(examId: String?) {
        _selectedLeaderboardExamId.value = examId
    }

    fun startExam(exam: Exam, profile: UserProfile, onReady: () -> Unit) {
        viewModelScope.launch {
            _isLoadingQuestions.value = true
            val result = examRepository.getExamQuestions(exam.id)
            _isLoadingQuestions.value = false
            result.onSuccess { questions ->
                if (questions.isEmpty()) {
                    _events.tryEmit("এই পরীক্ষায় এখনো কোনো প্রশ্ন যোগ করা হয়নি")
                    return@onSuccess
                }
                val totalSecs = (exam.durationMinutes.coerceAtLeast(1)) * 60
                _activeSession.value = ActiveExamSession(
                    exam = exam,
                    questions = questions,
                    currentQuestionIndex = 0,
                    selectedAnswers = emptyMap(),
                    remainingSeconds = totalSecs,
                    totalSeconds = totalSecs
                )
                startCountdownTimer(profile)
                onReady()
            }.onFailure { err ->
                _events.tryEmit(err.localizedMessage ?: "প্রশ্ন লোড করতে সমস্যা হয়েছে")
            }
        }
    }

    private fun startCountdownTimer(profile: UserProfile) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val session = _activeSession.value ?: break
                if (session.isSubmitting) break
                val next = session.remainingSeconds - 1
                if (next <= 0) {
                    _activeSession.value = session.copy(remainingSeconds = 0)
                    submitActiveExam(profile = profile, autoSubmitted = true)
                    break
                } else {
                    _activeSession.value = session.copy(remainingSeconds = next)
                }
            }
        }
    }

    fun selectAnswer(questionId: String, optionIndex: Int) {
        val current = _activeSession.value ?: return
        if (current.isSubmitting) return
        val updated = current.selectedAnswers.toMutableMap().apply {
            this[questionId] = optionIndex
        }
        _activeSession.value = current.copy(selectedAnswers = updated)
    }

    fun navigateToQuestion(index: Int) {
        val current = _activeSession.value ?: return
        if (index in current.questions.indices) {
            _activeSession.value = current.copy(currentQuestionIndex = index)
        }
    }

    fun submitActiveExam(
        profile: UserProfile,
        autoSubmitted: Boolean = false,
        onSubmitted: (ExamAttempt) -> Unit = {}
    ) {
        val session = _activeSession.value ?: return
        if (session.isSubmitting) return
        timerJob?.cancel()
        _activeSession.value = session.copy(isSubmitting = true)

        viewModelScope.launch {
            val timeTaken = (session.totalSeconds - session.remainingSeconds).coerceAtLeast(0)
            val result = examRepository.submitExamAttempt(
                exam = session.exam,
                questions = session.questions,
                selectedAnswers = session.selectedAnswers,
                profile = profile,
                timeTakenSeconds = timeTaken,
                autoSubmitted = autoSubmitted
            )
            result.onSuccess { attempt ->
                _reviewQuestions.value = session.questions
                _lastSubmittedAttempt.value = attempt
                _activeSession.value = null
                _selectedLeaderboardExamId.value = session.exam.id
                _events.tryEmit(
                    if (autoSubmitted) "সময় শেষ! পরীক্ষা স্বয়ংক্রিয়ভাবে জমা হয়েছে।"
                    else "পরীক্ষা সফলভাবে জমা হয়েছে!"
                )
                onSubmitted(attempt)
            }.onFailure { err ->
                _activeSession.value = session.copy(isSubmitting = false)
                _events.tryEmit(err.localizedMessage ?: "পরীক্ষা জমা দিতে সমস্যা হয়েছে")
            }
        }
    }

    fun cancelExamSession() {
        timerJob?.cancel()
        _activeSession.value = null
    }

    fun loadAttemptReview(attempt: ExamAttempt, onLoaded: () -> Unit) {
        viewModelScope.launch {
            _isLoadingQuestions.value = true
            _lastSubmittedAttempt.value = attempt
            _selectedLeaderboardExamId.value = attempt.examId
            val res = examRepository.getExamQuestions(attempt.examId)
            _isLoadingQuestions.value = false
            res.onSuccess { questions ->
                _reviewQuestions.value = questions
                onLoaded()
            }.onFailure { err ->
                _events.tryEmit(err.localizedMessage ?: "উত্তরপত্র লোড হয়নি")
            }
        }
    }

    private fun <T> kotlinx.coroutines.flow.Flow<T>.toUiState(fallback: String): kotlinx.coroutines.flow.Flow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, fallback, root)
                emit(UiState.Error(extractRootFirestoreMessage(root, fallback)))
            }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }

    private companion object {
        const val TAG = "ExamViewModel"
    }
}
