package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Blue & White Academic Palette
val AbirRoyalBlue = Color(0xFF1565C0)
val AbirDeepBlue = Color(0xFF0D47A1)
val AbirAzure = Color(0xFF1E88E5)
val AbirSkyContainer = Color(0xFFE3F2FD)
val AbirOnSkyContainer = Color(0xFF082E5C)

val AbirSoftBackground = Color(0xFFF6F9FF)
val AbirPureWhite = Color(0xFFFFFFFF)
val AbirCardBorder = Color(0xFFDCE7F7)
val AbirMutedSlate = Color(0xFF5A6B85)
val AbirInkNavy = Color(0xFF0F1E36)

// Secondary & Accents
val AbirTealAccent = Color(0xFF0288D1)
val AbirTealContainer = Color(0xFFE0F7FA)
val AbirSuccessGreen = Color(0xFF1B8A5A)
val AbirSuccessContainer = Color(0xFFE6F6EE)
val AbirWarningAmber = Color(0xFFD97706)
val AbirWarningContainer = Color(0xFFFEF3C7)
val AbirErrorRed = Color(0xFFC62828)
val AbirErrorContainer = Color(0xFFFEE2E2)

// Dark Theme Blue-Slate Surfaces
val AbirDarkBackground = Color(0xFF0A1322)
val AbirDarkSurface = Color(0xFF111D32)
val AbirDarkSurfaceVariant = Color(0xFF1B2B47)
val AbirDarkPrimary = Color(0xFF7AB8FF)
val AbirDarkOnPrimary = Color(0xFF002B5C)
val AbirDarkOutline = Color(0xFF2B3F61)
