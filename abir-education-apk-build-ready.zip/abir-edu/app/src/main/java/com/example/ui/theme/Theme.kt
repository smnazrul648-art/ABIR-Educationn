package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = AbirRoyalBlue,
    onPrimary = AbirPureWhite,
    primaryContainer = AbirSkyContainer,
    onPrimaryContainer = AbirOnSkyContainer,
    secondary = AbirTealAccent,
    onSecondary = AbirPureWhite,
    secondaryContainer = AbirTealContainer,
    onSecondaryContainer = AbirDeepBlue,
    tertiary = AbirSuccessGreen,
    onTertiary = AbirPureWhite,
    tertiaryContainer = AbirSuccessContainer,
    onTertiaryContainer = Color(0xFF0A3D26),
    background = AbirSoftBackground,
    onBackground = AbirInkNavy,
    surface = AbirPureWhite,
    onSurface = AbirInkNavy,
    surfaceVariant = Color(0xFFEAF1FB),
    onSurfaceVariant = AbirMutedSlate,
    outline = AbirCardBorder,
    outlineVariant = Color(0xFFE6EEF9),
    error = AbirErrorRed,
    onError = AbirPureWhite,
    errorContainer = AbirErrorContainer,
    onErrorContainer = Color(0xFF690005)
)

private val DarkColors = darkColorScheme(
    primary = AbirDarkPrimary,
    onPrimary = AbirDarkOnPrimary,
    primaryContainer = AbirDeepBlue,
    onPrimaryContainer = AbirSkyContainer,
    secondary = Color(0xFF67D4F5),
    onSecondary = Color(0xFF003547),
    secondaryContainer = Color(0xFF004D66),
    onSecondaryContainer = AbirTealContainer,
    tertiary = Color(0xFF6EE7B7),
    onTertiary = Color(0xFF003824),
    tertiaryContainer = Color(0xFF065F46),
    onTertiaryContainer = AbirSuccessContainer,
    background = AbirDarkBackground,
    onBackground = Color(0xFFEBF2FF),
    surface = AbirDarkSurface,
    onSurface = Color(0xFFEBF2FF),
    surfaceVariant = AbirDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFA7B8D6),
    outline = AbirDarkOutline,
    outlineVariant = Color(0xFF213250),
    error = Color(0xFFFF897D),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = AbirErrorContainer
)

val AbirShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun AbirEducationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AbirShapes,
        content = content
    )
}
