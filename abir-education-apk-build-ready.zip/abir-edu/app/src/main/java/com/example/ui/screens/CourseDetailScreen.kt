package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.local.OfflineNoteEntity
import com.example.model.Bookmark
import com.example.model.Chapter
import com.example.model.Course
import com.example.model.Lesson
import com.example.model.LessonProgress
import com.example.model.LessonType
import com.example.model.UiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.LoadingStateView
import com.example.ui.components.StatusBadge
import com.example.util.BanglaDateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseDetailScreen(
    course: Course,
    language: AppLanguage,
    chaptersState: UiState<List<Chapter>>,
    lessonsState: UiState<List<Lesson>>,
    bookmarks: List<Bookmark>,
    progressList: List<LessonProgress>,
    offlineNotes: List<OfflineNoteEntity>,
    downloadingLessonIds: Set<String>,
    onBack: () -> Unit,
    onOpenLesson: (Lesson) -> Unit,
    onToggleBookmark: (Lesson, Boolean) -> Unit,
    onDownloadOffline: (Lesson) -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    val bookmarkedIds = bookmarks.map { it.lessonId }.toSet()
    val completedIds = progressList.filter { it.completed }.map { it.lessonId }.toSet()
    val offlineIds = offlineNotes.map { it.lessonId }.toSet()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(course.displayTitle(isBangla), maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatusBadge(text = BanglaDateUtils.formatClassLabel(course.classLevel, isBangla))
                            StatusBadge(text = course.subjectNameBn)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = course.displayTitle(isBangla),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        if (course.displayDesc(isBangla).isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(course.displayDesc(isBangla), style = MaterialTheme.typography.bodyMedium)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "${if (isBangla) "শিক্ষক:" else "Instructor:"} ${course.instructorName}",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            when {
                chaptersState is UiState.Loading || lessonsState is UiState.Loading -> {
                    item { LoadingStateView(strings.loadingLabel) }
                }
                chaptersState is UiState.Error -> {
                    item { ErrorRetryCard(chaptersState.message, strings.retryLabel) }
                }
                lessonsState is UiState.Error -> {
                    item { ErrorRetryCard(lessonsState.message, strings.retryLabel) }
                }
                else -> {
                    val chapters = (chaptersState as? UiState.Success)?.data.orEmpty()
                    val lessons = (lessonsState as? UiState.Success)?.data.orEmpty()

                    if (lessons.isEmpty()) {
                        item { EmptyStateCard(title = if (isBangla) "এই কোর্সে এখনো কোনো পাঠ যুক্ত হয়নি" else "No lessons added to this course yet") }
                    } else if (chapters.isEmpty()) {
                        items(lessons, key = { it.id }) { lesson ->
                            LessonRowCard(
                                lesson = lesson,
                                isBangla = isBangla,
                                isBookmarked = lesson.id in bookmarkedIds,
                                isCompleted = lesson.id in completedIds,
                                isOfflineSaved = lesson.id in offlineIds,
                                isDownloading = lesson.id in downloadingLessonIds,
                                onOpen = { onOpenLesson(lesson) },
                                onToggleBookmark = { onToggleBookmark(lesson, lesson.id in bookmarkedIds) },
                                onDownloadOffline = { onDownloadOffline(lesson) }
                            )
                        }
                    } else {
                        chapters.forEach { chapter ->
                            val chapterLessons = lessons.filter { it.chapterId == chapter.id }
                            item(key = "chap_${chapter.id}") {
                                Text(
                                    text = chapter.displayTitle(isBangla),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                            if (chapterLessons.isEmpty()) {
                                item(key = "chap_empty_${chapter.id}") {
                                    Text(
                                        text = if (isBangla) "এই অধ্যায়ে এখনো কোনো পাঠ নেই" else "No lessons in this chapter",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            } else {
                                items(chapterLessons, key = { it.id }) { lesson ->
                                    LessonRowCard(
                                        lesson = lesson,
                                        isBangla = isBangla,
                                        isBookmarked = lesson.id in bookmarkedIds,
                                        isCompleted = lesson.id in completedIds,
                                        isOfflineSaved = lesson.id in offlineIds,
                                        isDownloading = lesson.id in downloadingLessonIds,
                                        onOpen = { onOpenLesson(lesson) },
                                        onToggleBookmark = { onToggleBookmark(lesson, lesson.id in bookmarkedIds) },
                                        onDownloadOffline = { onDownloadOffline(lesson) }
                                    )
                                }
                            }
                        }

                        val unassigned = lessons.filter { l -> chapters.none { it.id == l.chapterId } }
                        if (unassigned.isNotEmpty()) {
                            item {
                                Text(
                                    text = strings.lessonsTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            items(unassigned, key = { it.id }) { lesson ->
                                LessonRowCard(
                                    lesson = lesson,
                                    isBangla = isBangla,
                                    isBookmarked = lesson.id in bookmarkedIds,
                                    isCompleted = lesson.id in completedIds,
                                    isOfflineSaved = lesson.id in offlineIds,
                                    isDownloading = lesson.id in downloadingLessonIds,
                                    onOpen = { onOpenLesson(lesson) },
                                    onToggleBookmark = { onToggleBookmark(lesson, lesson.id in bookmarkedIds) },
                                    onDownloadOffline = { onDownloadOffline(lesson) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonRowCard(
    lesson: Lesson,
    isBangla: Boolean,
    isBookmarked: Boolean,
    isCompleted: Boolean,
    isOfflineSaved: Boolean,
    isDownloading: Boolean,
    onOpen: () -> Unit,
    onToggleBookmark: () -> Unit,
    onDownloadOffline: () -> Unit
) {
    val typeIcon = when (lesson.parsedType()) {
        LessonType.PDF -> Icons.Default.PictureAsPdf
        LessonType.VIDEO -> Icons.Default.PlayCircle
        LessonType.TEXT -> Icons.Default.Article
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = typeIcon,
                contentDescription = lesson.lessonType,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = lesson.displayTitle(isBangla),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "${lesson.lessonType} • ${BanglaDateUtils.formatNumber(lesson.durationMinutes, isBangla)} ${if (isBangla) "মি." else "min"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            if (isDownloading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = onDownloadOffline) {
                    Icon(
                        imageVector = if (isOfflineSaved) Icons.Default.DownloadDone else Icons.Default.Download,
                        contentDescription = "Download offline",
                        tint = if (isOfflineSaved) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = onToggleBookmark) {
                Icon(
                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
