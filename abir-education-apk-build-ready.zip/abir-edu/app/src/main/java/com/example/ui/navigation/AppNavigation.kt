package com.example.ui.navigation

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.i18n.AppLanguage
import com.example.i18n.AppStrings
import com.example.i18n.stringsFor
import com.example.local.OfflineNoteEntity
import com.example.local.OfflineRepository
import com.example.model.Course
import com.example.model.Lesson
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.repository.AdminRepository
import com.example.repository.AuthRepository
import com.example.repository.ExamRepository
import com.example.repository.StudentRepository
import com.example.repository.authStateFlow
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.LoadingStateView
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CourseDetailScreen
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.ExamResultDetailScreen
import com.example.ui.screens.ExamTakingScreen
import com.example.ui.screens.ExamsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LessonViewerScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.admin.AdminPanelScreen
import com.example.ui.theme.AbirEducationTheme
import com.example.viewmodel.AdminViewModel
import com.example.viewmodel.ExamViewModel
import com.example.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

object AppRoutes {
    const val HOME = "home"
    const val COURSES = "courses"
    const val EXAMS = "exams"
    const val RESULTS = "results"
    const val PROFILE = "profile"
    const val COURSE_DETAIL = "course_detail/{courseId}"
    const val LESSON_VIEWER = "lesson_viewer/{lessonId}"
    const val EXAM_TAKING = "exam_taking"
    const val RESULT_DETAIL = "result_detail"
    const val ADMIN_PANEL = "admin_panel"

    fun courseDetail(courseId: String) = "course_detail/$courseId"
    fun lessonViewer(lessonId: String) = "lesson_viewer/$lessonId"
}

private data class TopDestination(
    val route: String,
    val testTag: String,
    val label: (AppStrings) -> String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val TopDestinations = listOf(
    TopDestination(AppRoutes.HOME, "bottom_nav_home", { it.navHome }, Icons.Filled.Home, Icons.Outlined.Home),
    TopDestination(AppRoutes.COURSES, "bottom_nav_courses", { it.navCourses }, Icons.Filled.MenuBook, Icons.Outlined.MenuBook),
    TopDestination(AppRoutes.EXAMS, "bottom_nav_exams", { it.navExams }, Icons.Filled.Quiz, Icons.Outlined.Quiz),
    TopDestination(AppRoutes.RESULTS, "bottom_nav_results", { it.navResults }, Icons.Filled.Assessment, Icons.Outlined.Assessment),
    TopDestination(AppRoutes.PROFILE, "bottom_nav_profile", { it.navProfile }, Icons.Filled.Person, Icons.Outlined.Person)
)

@Composable
fun AppNavigation() {
    val authUser by Firebase.auth.authStateFlow().collectAsStateWithLifecycle(
        initialValue = Firebase.auth.currentUser
    )

    val user = authUser
    if (user == null) {
        AbirEducationTheme(darkTheme = false) {
            AuthScreen(
                onAuthSuccess = {
                    // authStateFlow automatically transitions to AuthenticatedApp
                }
            )
        }
    } else {
        key(user.uid) {
            AuthenticatedApp(currentUser = user)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedApp(currentUser: FirebaseUser) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val scope = rememberCoroutineScope()
    val isOwner = remember(currentUser.uid, currentUser.email, currentUser.isEmailVerified) {
        AuthRepository.isVerifiedOwnerEmail(currentUser)
    }

    val factory = remember(currentUser.uid) {
        viewModelFactory {
            initializer {
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                MainViewModel(
                    studentRepository = StudentRepository(db),
                    offlineRepository = OfflineRepository(app),
                    currentUser = currentUser
                )
            }
            initializer {
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                ExamViewModel(
                    examRepository = ExamRepository(db),
                    currentUserId = currentUser.uid
                )
            }
            initializer {
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                AdminViewModel(
                    adminRepository = AdminRepository(db),
                    currentUserId = currentUser.uid
                )
            }
        }
    }

    val mainViewModel: MainViewModel = viewModel(key = "main_${currentUser.uid}", factory = factory)
    val examViewModel: ExamViewModel = viewModel(key = "exam_${currentUser.uid}", factory = factory)
    val adminViewModel: AdminViewModel = viewModel(key = "admin_${currentUser.uid}", factory = factory)

    val language by mainViewModel.language.collectAsStateWithLifecycle()
    val darkMode by mainViewModel.darkMode.collectAsStateWithLifecycle()
    val userProfileState by mainViewModel.userProfile.collectAsStateWithLifecycle()
    val strings = stringsFor(language)

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Permission result handled gracefully by system notification setting */ }

    LaunchedEffect(currentUser.uid) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        try {
            val token = FirebaseMessaging.getInstance().token.await()
            val dbId = app.getString(R.string.firestore_database_id)
            FirebaseFirestore.getInstance(dbId)
                .collection("users")
                .document(currentUser.uid)
                .update(
                    mapOf(
                        "fcmToken" to token,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
        } catch (e: Exception) {
            Log.d("AppNavigation", "FCM token sync deferred: ${e.message}")
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(mainViewModel, examViewModel, adminViewModel) {
        launch {
            mainViewModel.events.collect { msg -> snackbarHostState.showSnackbar(msg) }
        }
        launch {
            examViewModel.events.collect { msg -> snackbarHostState.showSnackbar(msg) }
        }
        launch {
            adminViewModel.events.collect { msg -> snackbarHostState.showSnackbar(msg) }
        }
    }

    AbirEducationTheme(darkTheme = darkMode) {
        val loadedProfile = (userProfileState as? UiState.Success)?.data
        if (loadedProfile?.suspended == true && !isOwner) {
            SuspendedAccountGate(
                strings = strings,
                onSignOut = { scope.launch { AuthRepository.signOut(context) } }
            )
            return@AbirEducationTheme
        }

        val effectiveProfile = loadedProfile ?: UserProfile(
            uid = currentUser.uid,
            name = currentUser.displayName ?: "Student",
            email = currentUser.email ?: "",
            photoUrl = currentUser.photoUrl?.toString(),
            classLevel = 10,
            preferredLanguage = AppLanguage.BN.code
        )

        val navController = rememberNavController()
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = backStackEntry?.destination?.route ?: AppRoutes.HOME
        val isTopLevel = TopDestinations.any { it.route == currentRoute }

        val subjectsState by mainViewModel.subjectsState.collectAsStateWithLifecycle()
        val coursesState by mainViewModel.coursesState.collectAsStateWithLifecycle()
        val allLessonsState by mainViewModel.allLessonsState.collectAsStateWithLifecycle()
        val announcementsState by mainViewModel.announcementsState.collectAsStateWithLifecycle()
        val bookmarksState by mainViewModel.bookmarksState.collectAsStateWithLifecycle()
        val progressState by mainViewModel.progressState.collectAsStateWithLifecycle()
        val offlineNotes by mainViewModel.offlineNotes.collectAsStateWithLifecycle()
        val appConfig by mainViewModel.appConfig.collectAsStateWithLifecycle()
        val selectedClassFilter by mainViewModel.selectedClassFilter.collectAsStateWithLifecycle()
        val selectedSubjectId by mainViewModel.selectedSubjectId.collectAsStateWithLifecycle()
        val searchQuery by mainViewModel.searchQuery.collectAsStateWithLifecycle()
        val filteredCourses by mainViewModel.filteredCourses.collectAsStateWithLifecycle()
        val activeChapters by mainViewModel.activeCourseChapters.collectAsStateWithLifecycle()
        val activeLessons by mainViewModel.activeCourseLessons.collectAsStateWithLifecycle()
        val downloadingLessonIds by mainViewModel.downloadingLessonIds.collectAsStateWithLifecycle()

        val publishedExamsState by examViewModel.publishedExamsState.collectAsStateWithLifecycle()
        val myAttemptsState by examViewModel.myAttemptsState.collectAsStateWithLifecycle()
        val selectedLeaderboardExamId by examViewModel.selectedLeaderboardExamId.collectAsStateWithLifecycle()
        val leaderboardState by examViewModel.leaderboardState.collectAsStateWithLifecycle()
        val activeExamSession by examViewModel.activeSession.collectAsStateWithLifecycle()
        val isLoadingQuestions by examViewModel.isLoadingQuestions.collectAsStateWithLifecycle()
        val lastAttempt by examViewModel.lastSubmittedAttempt.collectAsStateWithLifecycle()
        val reviewQuestions by examViewModel.reviewQuestions.collectAsStateWithLifecycle()

        var fallbackCourse by remember { mutableStateOf<Course?>(null) }
        var fallbackLesson by remember { mutableStateOf<Lesson?>(null) }

        val navigateTopTab: (String) -> Unit = { route ->
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        val openCourseDetail: (Course) -> Unit = { course ->
            fallbackCourse = course
            mainViewModel.setActiveCourse(course.id)
            navController.navigate(AppRoutes.courseDetail(course.id))
        }

        val openLessonDetail: (Lesson) -> Unit = { lesson ->
            fallbackLesson = lesson
            navController.navigate(AppRoutes.lessonViewer(lesson.id))
        }

        val openOfflineNote: (OfflineNoteEntity) -> Unit = { offline ->
            val liveMatch = (allLessonsState as? UiState.Success)?.data
                ?.firstOrNull { it.id == offline.lessonId }
            fallbackLesson = liveMatch ?: offline.toLessonFallback()
            navController.navigate(AppRoutes.lessonViewer(offline.lessonId))
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Row(modifier = Modifier.fillMaxSize()) {
                if (useRail && isTopLevel) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        Spacer(Modifier.height(12.dp))
                        TopDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label(strings)
                                    )
                                },
                                label = { Text(dest.label(strings)) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentWindowInsets = if (isTopLevel) WindowInsets.safeDrawing else WindowInsets(0, 0, 0, 0),
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    topBar = {
                        if (isTopLevel) {
                            TopAppBar(
                                title = {
                                    Text(
                                        text = strings.appName,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                        }
                    },
                    bottomBar = {
                        if (!useRail && isTopLevel) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                TopDestinations.forEach { dest ->
                                    val selected = currentRoute == dest.route
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { navigateTopTab(dest.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.label(strings)
                                            )
                                        },
                                        label = { Text(dest.label(strings), maxLines = 1) },
                                        modifier = Modifier.testTag(dest.testTag)
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HOME,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        composable(AppRoutes.HOME) {
                            HomeScreen(
                                profile = effectiveProfile,
                                language = language,
                                subjectsState = subjectsState,
                                coursesState = coursesState,
                                announcementsState = announcementsState,
                                bookmarksState = bookmarksState,
                                progressState = progressState,
                                offlineNotes = offlineNotes,
                                searchQuery = searchQuery,
                                onSearchChange = {
                                    mainViewModel.updateSearchQuery(it)
                                },
                                onClassSelected = { level ->
                                    mainViewModel.updateClassLevel(level)
                                },
                                onOpenCoursesTab = { navigateTopTab(AppRoutes.COURSES) },
                                onOpenExamsTab = { navigateTopTab(AppRoutes.EXAMS) },
                                onOpenCourse = openCourseDetail,
                                onOpenOfflineNote = openOfflineNote
                            )
                        }

                        composable(AppRoutes.COURSES) {
                            CoursesScreen(
                                language = language,
                                selectedClassFilter = selectedClassFilter,
                                selectedSubjectId = selectedSubjectId,
                                searchQuery = searchQuery,
                                subjectsState = subjectsState,
                                coursesState = coursesState,
                                filteredCourses = filteredCourses,
                                allLessonsState = allLessonsState,
                                offlineNotes = offlineNotes,
                                onSelectClass = { mainViewModel.selectClassFilter(it) },
                                onSelectSubject = { mainViewModel.selectSubjectFilter(it) },
                                onSearchChange = { mainViewModel.updateSearchQuery(it) },
                                onOpenCourse = openCourseDetail,
                                onOpenLessonDirect = openLessonDetail,
                                onOpenOfflineNote = openOfflineNote,
                                onDeleteOfflineNote = { mainViewModel.removeOfflineNote(it) }
                            )
                        }

                        composable(
                            route = AppRoutes.COURSE_DETAIL,
                            arguments = listOf(navArgument("courseId") { type = NavType.StringType })
                        ) { entry ->
                            val courseId = entry.arguments?.getString("courseId").orEmpty()
                            LaunchedEffect(courseId) {
                                if (courseId.isNotBlank()) mainViewModel.setActiveCourse(courseId)
                            }
                            val course = (coursesState as? UiState.Success)?.data
                                ?.firstOrNull { it.id == courseId }
                                ?: fallbackCourse?.takeIf { it.id == courseId }

                            if (course == null) {
                                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    EmptyStateCard(title = strings.noCoursesFound)
                                }
                            } else {
                                val bookmarks = (bookmarksState as? UiState.Success)?.data.orEmpty()
                                val progress = (progressState as? UiState.Success)?.data.orEmpty()
                                CourseDetailScreen(
                                    course = course,
                                    language = language,
                                    chaptersState = activeChapters,
                                    lessonsState = activeLessons,
                                    bookmarks = bookmarks,
                                    progressList = progress,
                                    offlineNotes = offlineNotes,
                                    downloadingLessonIds = downloadingLessonIds,
                                    onBack = { navController.popBackStack() },
                                    onOpenLesson = openLessonDetail,
                                    onToggleBookmark = { l, currently ->
                                        mainViewModel.toggleBookmark(l, currently)
                                    },
                                    onDownloadOffline = { l ->
                                        mainViewModel.downloadLessonOffline(l)
                                    }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.LESSON_VIEWER,
                            arguments = listOf(navArgument("lessonId") { type = NavType.StringType })
                        ) { entry ->
                            val lessonId = entry.arguments?.getString("lessonId").orEmpty()
                            val offlineMatch = offlineNotes.firstOrNull { it.lessonId == lessonId }
                            val lesson = (allLessonsState as? UiState.Success)?.data
                                ?.firstOrNull { it.id == lessonId }
                                ?: (activeLessons as? UiState.Success)?.data?.firstOrNull { it.id == lessonId }
                                ?: fallbackLesson?.takeIf { it.id == lessonId }
                                ?: offlineMatch?.toLessonFallback()

                            if (lesson == null) {
                                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    LoadingStateView(strings.loadingLabel)
                                }
                            } else {
                                val isBookmarked = (bookmarksState as? UiState.Success)?.data
                                    ?.any { it.lessonId == lesson.id } == true
                                val isCompleted = (progressState as? UiState.Success)?.data
                                    ?.any { it.lessonId == lesson.id && it.completed } == true
                                LessonViewerScreen(
                                    lesson = lesson,
                                    language = language,
                                    isBookmarked = isBookmarked,
                                    isCompleted = isCompleted,
                                    offlineNote = offlineMatch,
                                    isDownloading = lesson.id in downloadingLessonIds,
                                    onBack = { navController.popBackStack() },
                                    onToggleBookmark = { mainViewModel.toggleBookmark(lesson, isBookmarked) },
                                    onDownloadOffline = { mainViewModel.downloadLessonOffline(lesson) },
                                    onMarkCompleted = { mainViewModel.markLessonCompleted(lesson, true) }
                                )
                            }
                        }

                        composable(AppRoutes.EXAMS) {
                            ExamsScreen(
                                language = language,
                                selectedClassFilter = selectedClassFilter,
                                examsState = publishedExamsState,
                                myAttemptsState = myAttemptsState,
                                isLoadingQuestions = isLoadingQuestions,
                                onSelectClass = { mainViewModel.selectClassFilter(it) },
                                onStartExam = { exam ->
                                    examViewModel.startExam(exam, effectiveProfile) {
                                        navController.navigate(AppRoutes.EXAM_TAKING)
                                    }
                                }
                            )
                        }

                        composable(AppRoutes.EXAM_TAKING) {
                            val session = activeExamSession
                            var enteredWithSession by remember { mutableStateOf(false) }
                            LaunchedEffect(session) {
                                if (session != null) {
                                    enteredWithSession = true
                                }
                            }
                            if (session == null) {
                                LaunchedEffect(enteredWithSession, lastAttempt) {
                                    if (enteredWithSession && lastAttempt != null) {
                                        navController.navigate(AppRoutes.RESULT_DETAIL) {
                                            popUpTo(AppRoutes.EXAMS)
                                        }
                                    } else {
                                        navController.popBackStack()
                                    }
                                }
                            } else {
                                ExamTakingScreen(
                                    session = session,
                                    language = language,
                                    onSelectOption = { qId, optIdx ->
                                        examViewModel.selectAnswer(qId, optIdx)
                                    },
                                    onNavigateQuestion = { idx ->
                                        examViewModel.navigateToQuestion(idx)
                                    },
                                    onSubmit = {
                                        examViewModel.submitActiveExam(profile = effectiveProfile)
                                    },
                                    onExitWithoutSubmitting = {
                                        examViewModel.cancelExamSession()
                                        navController.popBackStack()
                                    }
                                )
                            }
                        }

                        composable(AppRoutes.RESULTS) {
                            val exams = (publishedExamsState as? UiState.Success)?.data.orEmpty()
                            LaunchedEffect(exams) {
                                if (selectedLeaderboardExamId == null && exams.isNotEmpty()) {
                                    examViewModel.selectLeaderboardExam(exams.first().id)
                                }
                            }
                            ResultsScreen(
                                language = language,
                                myAttemptsState = myAttemptsState,
                                publishedExams = exams,
                                selectedLeaderboardExamId = selectedLeaderboardExamId,
                                leaderboardState = leaderboardState,
                                onSelectLeaderboardExam = { examViewModel.selectLeaderboardExam(it) },
                                onOpenAttemptReview = { attempt ->
                                    examViewModel.loadAttemptReview(attempt) {
                                        navController.navigate(AppRoutes.RESULT_DETAIL)
                                    }
                                }
                            )
                        }

                        composable(AppRoutes.RESULT_DETAIL) {
                            val attempt = lastAttempt
                            if (attempt == null) {
                                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    ErrorRetryCard(strings.noResultsFound, strings.retryLabel)
                                }
                            } else {
                                ExamResultDetailScreen(
                                    attempt = attempt,
                                    questions = reviewQuestions,
                                    language = language,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.PROFILE) {
                            val bookmarks = (bookmarksState as? UiState.Success)?.data.orEmpty()
                            ProfileScreen(
                                profile = effectiveProfile,
                                isOwnerEmailVerified = isOwner,
                                language = language,
                                darkMode = darkMode,
                                bookmarks = bookmarks,
                                appConfig = appConfig,
                                onUpdateName = { mainViewModel.updateDisplayName(it) },
                                onSelectClass = { mainViewModel.updateClassLevel(it) },
                                onToggleLanguage = { mainViewModel.updateLanguage(it) },
                                onToggleDarkMode = { mainViewModel.updateDarkMode(it) },
                                onToggleLeaderboardPrivacy = { mainViewModel.updateLeaderboardPrivacy(it) },
                                onOpenAdminPanel = {
                                    if (isOwner) {
                                        navController.navigate(AppRoutes.ADMIN_PANEL)
                                    }
                                },
                                onSignOut = {
                                    scope.launch { AuthRepository.signOut(context) }
                                }
                            )
                        }

                        composable(AppRoutes.ADMIN_PANEL) {
                            if (!isOwner) {
                                LaunchedEffect(Unit) { navController.popBackStack() }
                            } else {
                                AdminPanelScreen(
                                    adminViewModel = adminViewModel,
                                    appConfig = appConfig,
                                    language = language,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SuspendedAccountGate(
    strings: AppStrings,
    onSignOut: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.widthIn(max = 460.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Block,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(48.dp)
                )
                Text(
                    text = strings.suspendedNotice,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Button(
                    onClick = onSignOut,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(strings.signOut)
                }
            }
        }
    }
}

private fun OfflineNoteEntity.toLessonFallback(): Lesson = Lesson(
    id = lessonId,
    courseId = courseId,
    chapterId = "",
    subjectId = subjectId,
    classLevel = classLevel,
    titleBn = titleBn,
    titleEn = titleEn,
    contentBn = contentBn,
    contentEn = contentEn,
    lessonType = lessonType,
    pdfUrl = null,
    pdfStoragePath = null,
    videoUrl = null,
    durationMinutes = 10,
    order = 1,
    published = true
)
