package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.local.OfflineNoteEntity
import com.example.model.Course
import com.example.model.Lesson
import com.example.model.Subject
import com.example.model.UiState
import com.example.ui.components.ClassFilterRow
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.LoadingStateView
import com.example.ui.components.StatusBadge
import com.example.util.BanglaDateUtils

@Composable
fun CoursesScreen(
    language: AppLanguage,
    selectedClassFilter: Int?,
    selectedSubjectId: String?,
    searchQuery: String,
    subjectsState: UiState<List<Subject>>,
    coursesState: UiState<List<Course>>,
    filteredCourses: List<Course>,
    allLessonsState: UiState<List<Lesson>>,
    offlineNotes: List<OfflineNoteEntity>,
    onSelectClass: (Int?) -> Unit,
    onSelectSubject: (String?) -> Unit,
    onSearchChange: (String) -> Unit,
    onOpenCourse: (Course) -> Unit,
    onOpenLessonDirect: (Lesson) -> Unit,
    onOpenOfflineNote: (OfflineNoteEntity) -> Unit,
    onDeleteOfflineNote: (String) -> Unit
) {
    val isBangla = language == AppLanguage.BN
    val strings = stringsFor(language)
    var selectedTab by remember { mutableIntStateOf(0) }

    val subjects = (subjectsState as? UiState.Success)?.data.orEmpty()
        .filter { selectedClassFilter == null || it.classLevel == selectedClassFilter }

    val matchingLessons = remember(allLessonsState, searchQuery, selectedClassFilter) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else {
            val all = (allLessonsState as? UiState.Success)?.data.orEmpty()
            all.filter { l ->
                (selectedClassFilter == null || l.classLevel == selectedClassFilter) &&
                    (l.titleBn.lowercase().contains(q) || l.titleEn.lowercase().contains(q))
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(strings.navCourses) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Text("${strings.offlineNotesTitle} (${BanglaDateUtils.formatNumber(offlineNotes.size, isBangla)})")
                }
            )
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        placeholder = { Text(strings.searchPlaceholder) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_courses_input")
                    )
                }

                item {
                    ClassFilterRow(
                        selectedClass = selectedClassFilter,
                        allLabel = strings.allClasses,
                        isBangla = isBangla,
                        includeAllOption = true,
                        onSelect = onSelectClass
                    )
                }

                if (subjects.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            subjects.forEach { subject ->
                                FilterChip(
                                    selected = selectedSubjectId == subject.id,
                                    onClick = { onSelectSubject(subject.id) },
                                    label = { Text(subject.displayName(isBangla)) }
                                )
                            }
                        }
                    }
                }

                if (matchingLessons.isNotEmpty()) {
                    item {
                        Text(
                            text = if (isBangla) "পাঠ অনুসন্ধান ফলাফল" else "Matching Lessons",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(matchingLessons.take(10), key = { "search_${it.id}" }) { lesson ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenLessonDirect(lesson) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusBadge(text = lesson.lessonType)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(lesson.displayTitle(isBangla), style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        BanglaDateUtils.formatClassLabel(lesson.classLevel, isBangla),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                when (coursesState) {
                    is UiState.Loading -> item { LoadingStateView(strings.loadingLabel) }
                    is UiState.Error -> item {
                        ErrorRetryCard(message = coursesState.message, retryLabel = strings.retryLabel)
                    }
                    is UiState.Success -> {
                        if (filteredCourses.isEmpty()) {
                            item { EmptyStateCard(title = strings.noCoursesFound) }
                        } else {
                            items(filteredCourses, key = { it.id }) { course ->
                                CourseSummaryCard(
                                    course = course,
                                    isBangla = isBangla,
                                    onClick = { onOpenCourse(course) }
                                )
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (offlineNotes.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = if (isBangla) "কোনো অফলাইন নোট ডাউনলোড করা নেই" else "No Offline Notes Downloaded",
                            subtitle = if (isBangla) "যেকোনো PDF বা টেক্সট লেসন খুলে অফলাইনের জন্য সংরক্ষণ করুন।" else "Open any lesson or PDF note and tap Download for Offline."
                        )
                    }
                } else {
                    items(offlineNotes, key = { it.lessonId }) { note ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenOfflineNote(note) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DownloadDone,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isBangla) note.titleBn else note.titleEn,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${BanglaDateUtils.formatClassLabel(note.classLevel, isBangla)} • ${note.lessonType} • ${BanglaDateUtils.formatReadableDateTime(note.savedAtMillis, isBangla)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { onDeleteOfflineNote(note.lessonId) }) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = strings.removeOffline,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
