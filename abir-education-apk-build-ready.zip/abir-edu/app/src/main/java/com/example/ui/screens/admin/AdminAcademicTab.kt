package com.example.ui.screens.admin

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Chapter
import com.example.model.Course
import com.example.model.Lesson
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.util.BanglaDateUtils
import com.example.viewmodel.AdminViewModel

@Composable
fun AdminAcademicTab(
    adminViewModel: AdminViewModel,
    classes: List<SchoolClass>,
    subjects: List<Subject>,
    courses: List<Course>,
    chapters: List<Chapter>,
    lessons: List<Lesson>,
    isBangla: Boolean
) {
    val context = LocalContext.current
    var section by remember { mutableIntStateOf(0) } // 0: Classes, 1: Subjects, 2: Courses, 3: Chapters, 4: Lessons

    var showClassDialog by remember { mutableStateOf(false) }
    var showSubjectDialog by remember { mutableStateOf(false) }
    var showCourseDialog by remember { mutableStateOf(false) }
    var showChapterDialog by remember { mutableStateOf(false) }
    var showLessonDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val labels = if (isBangla) {
                listOf("শ্রেণি (${classes.size})", "বিষয় (${subjects.size})", "কোর্স (${courses.size})", "অধ্যায় (${chapters.size})", "লেসন/PDF (${lessons.size})")
            } else {
                listOf("Classes (${classes.size})", "Subjects (${subjects.size})", "Courses (${courses.size})", "Chapters (${chapters.size})", "Lessons (${lessons.size})")
            }
            labels.forEachIndexed { idx, label ->
                FilterChip(
                    selected = section == idx,
                    onClick = { section = idx },
                    label = { Text(label) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Button(
                    onClick = {
                        when (section) {
                            0 -> showClassDialog = true
                            1 -> showSubjectDialog = true
                            2 -> showCourseDialog = true
                            3 -> showChapterDialog = true
                            4 -> showLessonDialog = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        when (section) {
                            0 -> if (isBangla) "নতুন শ্রেণি যোগ/সম্পাদনা" else "Add / Edit Class"
                            1 -> if (isBangla) "নতুন বিষয় যোগ করুন" else "Add Subject"
                            2 -> if (isBangla) "নতুন কোর্স তৈরি করুন" else "Create Course"
                            3 -> if (isBangla) "নতুন অধ্যায় যোগ করুন" else "Add Chapter"
                            else -> if (isBangla) "নতুন লেসন / PDF / ভিডিও যোগ করুন" else "Add Lesson / PDF / Video"
                        }
                    )
                }
            }

            when (section) {
                0 -> items(classes, key = { it.id }) { cls ->
                    AdminItemRow(
                        title = cls.displayName(isBangla),
                        subtitle = "Level ${cls.level} • ${if (cls.published) "Published" else "Draft"}",
                        onDelete = { adminViewModel.deleteClass(cls.id) }
                    )
                }
                1 -> items(subjects, key = { it.id }) { sub ->
                    AdminItemRow(
                        title = sub.displayName(isBangla),
                        subtitle = "${BanglaDateUtils.formatClassLabel(sub.classLevel, isBangla)} • ${if (sub.published) "Published" else "Draft"}",
                        onDelete = { adminViewModel.deleteSubject(sub.id) }
                    )
                }
                2 -> items(courses, key = { it.id }) { course ->
                    AdminItemRow(
                        title = course.displayTitle(isBangla),
                        subtitle = "${BanglaDateUtils.formatClassLabel(course.classLevel, isBangla)} • ${course.subjectNameBn} • ${course.instructorName}",
                        onDelete = { adminViewModel.deleteCourse(course.id) }
                    )
                }
                3 -> items(chapters, key = { it.id }) { chap ->
                    AdminItemRow(
                        title = chap.displayTitle(isBangla),
                        subtitle = "${BanglaDateUtils.formatClassLabel(chap.classLevel, isBangla)} • Course: ${chap.courseId.take(8)}",
                        onDelete = { adminViewModel.deleteChapter(chap.id) }
                    )
                }
                4 -> items(lessons, key = { it.id }) { lesson ->
                    AdminItemRow(
                        title = lesson.displayTitle(isBangla),
                        subtitle = "${lesson.lessonType} • ${BanglaDateUtils.formatClassLabel(lesson.classLevel, isBangla)}",
                        onDelete = { adminViewModel.deleteLesson(lesson.id) }
                    )
                }
            }
        }
    }

    if (showClassDialog) {
        var level by remember { mutableStateOf("10") }
        var nameBn by remember { mutableStateOf("দশম শ্রেণি") }
        var nameEn by remember { mutableStateOf("Class 10") }
        var published by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showClassDialog = false },
            title = { Text(if (isBangla) "শ্রেণি যোগ/আপডেট" else "Add/Update Class") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = level, onValueChange = { level = it }, label = { Text("Level (1-12)") })
                    OutlinedTextField(value = nameBn, onValueChange = { nameBn = it }, label = { Text("বাংলা নাম") })
                    OutlinedTextField(value = nameEn, onValueChange = { nameEn = it }, label = { Text("English Name") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Published", modifier = Modifier.weight(1f))
                        Switch(checked = published, onCheckedChange = { published = it })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val lvl = level.toIntOrNull()?.coerceIn(1, 12) ?: 10
                    adminViewModel.saveClass(
                        SchoolClass(
                            id = "class_$lvl",
                            level = lvl,
                            nameBn = nameBn.ifBlank { "শ্রেণি $lvl" },
                            nameEn = nameEn.ifBlank { "Class $lvl" },
                            published = published,
                            order = lvl
                        )
                    )
                    showClassDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showClassDialog = false }) { Text("Cancel") } }
        )
    }

    if (showSubjectDialog) {
        var classLevel by remember { mutableStateOf("10") }
        var nameBn by remember { mutableStateOf("") }
        var nameEn by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSubjectDialog = false },
            title = { Text(if (isBangla) "নতুন বিষয়" else "New Subject") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = classLevel, onValueChange = { classLevel = it }, label = { Text("Class (1-12)") })
                    OutlinedTextField(value = nameBn, onValueChange = { nameBn = it }, label = { Text("বিষয়ের নাম (বাংলা)") })
                    OutlinedTextField(value = nameEn, onValueChange = { nameEn = it }, label = { Text("Subject Name (English)") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nameBn.isNotBlank()) {
                        adminViewModel.saveSubject(
                            Subject(
                                classLevel = classLevel.toIntOrNull()?.coerceIn(1, 12) ?: 10,
                                nameBn = nameBn,
                                nameEn = nameEn.ifBlank { nameBn },
                                published = true,
                                order = subjects.size + 1
                            )
                        )
                        showSubjectDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSubjectDialog = false }) { Text("Cancel") } }
        )
    }

    if (showCourseDialog) {
        var selectedSubject by remember { mutableStateOf(subjects.firstOrNull()) }
        var titleBn by remember { mutableStateOf("") }
        var titleEn by remember { mutableStateOf("") }
        var descBn by remember { mutableStateOf("") }
        var instructor by remember { mutableStateOf("আবীর স্যার") }
        AlertDialog(
            onDismissRequest = { showCourseDialog = false },
            title = { Text(if (isBangla) "নতুন কোর্স" else "New Course") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(if (isBangla) "বিষয় নির্বাচন:" else "Select Subject:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        subjects.forEach { sub ->
                            FilterChip(
                                selected = selectedSubject?.id == sub.id,
                                onClick = { selectedSubject = sub },
                                label = { Text("${sub.nameBn} (${sub.classLevel})") }
                            )
                        }
                    }
                    OutlinedTextField(value = titleBn, onValueChange = { titleBn = it }, label = { Text("কোর্সের নাম (বাংলা)") })
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("Course Title (English)") })
                    OutlinedTextField(value = descBn, onValueChange = { descBn = it }, label = { Text("বিবরণ") })
                    OutlinedTextField(value = instructor, onValueChange = { instructor = it }, label = { Text("শিক্ষক") })
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedSubject != null && titleBn.isNotBlank(),
                    onClick = {
                        val sub = selectedSubject!!
                        adminViewModel.saveCourse(
                            Course(
                                classLevel = sub.classLevel,
                                subjectId = sub.id,
                                subjectNameBn = sub.nameBn,
                                titleBn = titleBn,
                                titleEn = titleEn.ifBlank { titleBn },
                                descriptionBn = descBn.takeIf { it.isNotBlank() },
                                instructorName = instructor.ifBlank { "ABIR Instructor" },
                                published = true
                            )
                        )
                        showCourseDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showCourseDialog = false }) { Text("Cancel") } }
        )
    }

    if (showChapterDialog) {
        var selectedCourse by remember { mutableStateOf(courses.firstOrNull()) }
        var titleBn by remember { mutableStateOf("") }
        var titleEn by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showChapterDialog = false },
            title = { Text(if (isBangla) "নতুন অধ্যায়" else "New Chapter") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isBangla) "কোর্স নির্বাচন:" else "Select Course:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        courses.forEach { c ->
                            FilterChip(
                                selected = selectedCourse?.id == c.id,
                                onClick = { selectedCourse = c },
                                label = { Text(c.titleBn) }
                            )
                        }
                    }
                    OutlinedTextField(value = titleBn, onValueChange = { titleBn = it }, label = { Text("অধ্যায়ের নাম (বাংলা)") })
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("Chapter Title (English)") })
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedCourse != null && titleBn.isNotBlank(),
                    onClick = {
                        val c = selectedCourse!!
                        adminViewModel.saveChapter(
                            Chapter(
                                courseId = c.id,
                                classLevel = c.classLevel,
                                titleBn = titleBn,
                                titleEn = titleEn.ifBlank { titleBn },
                                order = chapters.count { it.courseId == c.id } + 1,
                                published = true
                            )
                        )
                        showChapterDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showChapterDialog = false }) { Text("Cancel") } }
        )
    }

    if (showLessonDialog) {
        var selectedCourse by remember { mutableStateOf(courses.firstOrNull()) }
        var selectedChapter by remember { mutableStateOf(chapters.firstOrNull()) }
        var titleBn by remember { mutableStateOf("") }
        var titleEn by remember { mutableStateOf("") }
        var contentBn by remember { mutableStateOf("") }
        var lessonType by remember { mutableStateOf("TEXT") }
        var pdfUrl by remember { mutableStateOf("") }
        var videoUrl by remember { mutableStateOf("") }
        var pickedPdfUri by remember { mutableStateOf<Uri?>(null) }

        val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            pickedPdfUri = uri
        }

        AlertDialog(
            onDismissRequest = { showLessonDialog = false },
            title = { Text(if (isBangla) "নতুন লেসন / PDF / ভিডিও" else "New Lesson / PDF / Video") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(if (isBangla) "কোর্স:" else "Course:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        courses.forEach { c ->
                            FilterChip(
                                selected = selectedCourse?.id == c.id,
                                onClick = {
                                    selectedCourse = c
                                    selectedChapter = chapters.firstOrNull { it.courseId == c.id }
                                },
                                label = { Text(c.titleBn) }
                            )
                        }
                    }
                    val courseChapters = chapters.filter { it.courseId == selectedCourse?.id }
                    if (courseChapters.isNotEmpty()) {
                        Text(if (isBangla) "অধ্যায়:" else "Chapter:", style = MaterialTheme.typography.labelMedium)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            courseChapters.forEach { ch ->
                                FilterChip(
                                    selected = selectedChapter?.id == ch.id,
                                    onClick = { selectedChapter = ch },
                                    label = { Text(ch.titleBn) }
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("TEXT", "PDF", "VIDEO").forEach { type ->
                            FilterChip(selected = lessonType == type, onClick = { lessonType = type }, label = { Text(type) })
                        }
                    }
                    OutlinedTextField(value = titleBn, onValueChange = { titleBn = it }, label = { Text("পাঠের শিরোনাম (বাংলা)") })
                    OutlinedTextField(value = titleEn, onValueChange = { titleEn = it }, label = { Text("Lesson Title (English)") })
                    OutlinedTextField(value = contentBn, onValueChange = { contentBn = it }, label = { Text("স্টাডি নোট (বাংলা/English)") }, minLines = 3)
                    if (lessonType == "PDF") {
                        OutlinedButton(
                            onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (pickedPdfUri != null) "PDF নির্বাচিত হয়েছে" else "ডিভাইস থেকে PDF আপলোড করুন")
                        }
                        OutlinedTextField(value = pdfUrl, onValueChange = { pdfUrl = it }, label = { Text("অথবা সরাসরি PDF URL") })
                    }
                    if (lessonType == "VIDEO") {
                        OutlinedTextField(value = videoUrl, onValueChange = { videoUrl = it }, label = { Text("Video URL (MP4 / YouTube)") })
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedCourse != null && titleBn.isNotBlank(),
                    onClick = {
                        val c = selectedCourse!!
                        val chapId = selectedChapter?.id ?: "general_${c.id}"
                        adminViewModel.uploadPdfAndSaveLesson(
                            context = context,
                            pdfUri = pickedPdfUri,
                            lesson = Lesson(
                                courseId = c.id,
                                chapterId = chapId,
                                subjectId = c.subjectId,
                                classLevel = c.classLevel,
                                titleBn = titleBn,
                                titleEn = titleEn.ifBlank { titleBn },
                                contentBn = contentBn,
                                contentEn = contentBn,
                                lessonType = lessonType,
                                pdfUrl = pdfUrl.takeIf { it.isNotBlank() },
                                videoUrl = videoUrl.takeIf { it.isNotBlank() },
                                durationMinutes = 15,
                                order = lessons.count { it.courseId == c.id } + 1,
                                published = true
                            )
                        )
                        showLessonDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showLessonDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun AdminItemRow(
    title: String,
    subtitle: String,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
