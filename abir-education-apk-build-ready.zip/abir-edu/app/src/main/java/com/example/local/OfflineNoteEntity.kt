package com.example.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "offline_notes")
data class OfflineNoteEntity(
    @PrimaryKey val lessonId: String,
    val courseId: String,
    val subjectId: String,
    val classLevel: Int,
    val titleBn: String,
    val titleEn: String,
    val contentBn: String,
    val contentEn: String,
    val lessonType: String,
    val localPdfPath: String?,
    val fileSizeBytes: Long,
    val savedAtMillis: Long = System.currentTimeMillis()
)
