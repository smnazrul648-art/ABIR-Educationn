package com.example.repository

import com.example.model.Announcement
import com.example.model.AppConfig
import com.example.model.Bookmark
import com.example.model.Chapter
import com.example.model.Course
import com.example.model.Lesson
import com.example.model.LessonProgress
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.model.UserProfile
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudentRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    suspend fun ensureUserProfileExists(user: FirebaseUser): Result<Unit> {
        val path = "users/${user.uid}"
        return try {
            val docRef = db.collection("users").document(user.uid)
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) {
                val safeName = (user.displayName?.takeIf { it.isNotBlank() } ?: "Student").take(100)
                val safeEmail = user.email ?: ""
                val payload = mapOf(
                    "uid" to user.uid,
                    "name" to safeName,
                    "email" to safeEmail,
                    "photoUrl" to user.photoUrl?.toString()?.take(600),
                    "classLevel" to 10,
                    "preferredLanguage" to "bn",
                    "darkMode" to false,
                    "leaderboardOptIn" to true,
                    "suspended" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null } as Map<String, Any>
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }

    suspend fun updateProfilePreferences(
        userId: String,
        name: String? = null,
        classLevel: Int? = null,
        preferredLanguage: String? = null,
        darkMode: Boolean? = null,
        leaderboardOptIn: Boolean? = null
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user write." }
            val userRef = db.collection("users").document(userId)
            if (!userRef.get().await().exists()) {
                auth.currentUser?.let { ensureUserProfileExists(it) }
            }
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            name?.trim()?.takeIf { it.isNotEmpty() }?.let { updates["name"] = it.take(100) }
            classLevel?.let {
                require(it in 1..12) { "Class level must be between 1 and 12" }
                updates["classLevel"] = it
            }
            preferredLanguage?.let {
                require(it in listOf("bn", "en")) { "Invalid language code" }
                updates["preferredLanguage"] = it
            }
            darkMode?.let { updates["darkMode"] = it }
            leaderboardOptIn?.let { updates["leaderboardOptIn"] = it }

            userRef.update(updates).await()

            if (leaderboardOptIn != null) {
                val lbSnap = db.collection("leaderboard")
                    .whereEqualTo("userId", userId)
                    .get()
                    .await()
                if (!lbSnap.isEmpty) {
                    val batch = db.batch()
                    for (doc in lbSnap.documents) {
                        batch.update(
                            doc.reference,
                            mapOf(
                                "publicVisible" to leaderboardOptIn,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    batch.commit().await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observePublishedClasses(): Flow<List<SchoolClass>> =
        db.collection("classes")
            .whereEqualTo("published", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(SchoolClass::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.order }
            }

    fun observePublishedSubjects(): Flow<List<Subject>> =
        db.collection("subjects")
            .whereEqualTo("published", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(Subject::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.order }
            }

    fun observePublishedCourses(): Flow<List<Course>> =
        db.collection("courses")
            .whereEqualTo("published", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(Course::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.titleBn }
            }

    fun observeChaptersForCourse(courseId: String): Flow<List<Chapter>> =
        db.collection("chapters")
            .whereEqualTo("published", true)
            .whereEqualTo("courseId", courseId)
            .snapshots()
            .map { snap ->
                snap.toObjects(Chapter::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.order }
            }

    fun observeLessonsForCourse(courseId: String): Flow<List<Lesson>> =
        db.collection("lessons")
            .whereEqualTo("published", true)
            .whereEqualTo("courseId", courseId)
            .snapshots()
            .map { snap ->
                snap.toObjects(Lesson::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.order }
            }

    fun observeAllPublishedLessons(): Flow<List<Lesson>> =
        db.collection("lessons")
            .whereEqualTo("published", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(Lesson::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.order }
            }

    fun observeAnnouncements(): Flow<List<Announcement>> =
        db.collection("announcements")
            .whereEqualTo("published", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(Announcement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }

    fun observeAppConfig(): Flow<AppConfig> =
        db.collection("app_config").document("main")
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(AppConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: AppConfig()
                } else {
                    AppConfig()
                }
            }

    fun observeBookmarks(userId: String): Flow<List<Bookmark>> = flow {
        val path = "users/$userId/bookmarks"
        emitAll(
            db.collection("users").document(userId).collection("bookmarks")
                .snapshots()
                .map { snap ->
                    snap.toObjects(Bookmark::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun toggleBookmark(userId: String, lesson: Lesson, currentlyBookmarked: Boolean): Result<Unit> {
        val path = "users/$userId/bookmarks/${lesson.id}"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val docRef = db.collection("users").document(userId)
                .collection("bookmarks").document(lesson.id)
            if (currentlyBookmarked) {
                docRef.delete().await()
            } else {
                val payload = mapOf(
                    "lessonId" to lesson.id,
                    "courseId" to lesson.courseId,
                    "subjectId" to lesson.subjectId,
                    "classLevel" to lesson.classLevel.coerceIn(1, 12),
                    "titleBn" to lesson.titleBn.ifBlank { lesson.titleEn }.take(200),
                    "titleEn" to lesson.titleEn.ifBlank { lesson.titleBn }.take(200),
                    "lessonType" to lesson.parsedType().name,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeProgress(userId: String): Flow<List<LessonProgress>> = flow {
        val path = "users/$userId/progress"
        emitAll(
            db.collection("users").document(userId).collection("progress")
                .snapshots()
                .map { snap ->
                    snap.toObjects(LessonProgress::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun markLessonProgress(
        userId: String,
        lesson: Lesson,
        completed: Boolean,
        percent: Int = if (completed) 100 else 50
    ): Result<Unit> {
        val path = "users/$userId/progress/${lesson.id}"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val docRef = db.collection("users").document(userId)
                .collection("progress").document(lesson.id)
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "completed" to completed,
                        "progressPercent" to percent.coerceIn(0, 100),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "lessonId" to lesson.id,
                        "courseId" to lesson.courseId,
                        "subjectId" to lesson.subjectId,
                        "classLevel" to lesson.classLevel.coerceIn(1, 12),
                        "completed" to completed,
                        "progressPercent" to percent.coerceIn(0, 100),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }
}
