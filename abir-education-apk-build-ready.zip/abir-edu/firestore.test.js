const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "owner_admin_001";
const ADMIN_EMAIL = "smnazrul648@gmail.com";
const ALICE_UID = "student_alice_123";
const ALICE_EMAIL = "alice@example.com";
const BOB_UID = "student_bob_456";
const BOB_EMAIL = "bob@example.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function nowPast() {
  return new Date(Date.now() - 2000);
}

function nowFuture() {
  return new Date(Date.now() + 60000);
}

function adminDb() {
  return testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
}

function spoofedAdminDb() {
  return testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();
}

function studentDb(uid = ALICE_UID, email = ALICE_EMAIL) {
  return testEnv.authenticatedContext(uid, {
    email,
    email_verified: true,
  }).firestore();
}

async function seedAdminDoc() {
  const ts = nowPast();
  await adminDb().collection("admins").doc(ADMIN_UID).set({
    uid: ADMIN_UID,
    email: ADMIN_EMAIL,
    displayName: "Abir Owner",
    initializedAt: ts,
    updatedAt: ts,
  });
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users: denied read and write on all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("classes").where("published", "==", true).get());
  await assertFails(unauth.collection("courses").where("published", "==", true).get());
  await assertFails(unauth.collection("exams").where("published", "==", true).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("admins").doc(ADMIN_UID).get());
});

test("Admin security: only verified owner email can initialize admin; spoofed/student denied", async () => {
  const ts = nowPast();
  // Student cannot create admin doc
  await assertFails(
    studentDb().collection("admins").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: ADMIN_EMAIL,
      displayName: "Fake Admin",
      initializedAt: ts,
      updatedAt: ts,
    })
  );

  // Unverified email spoof cannot create admin doc
  await assertFails(
    spoofedAdminDb().collection("admins").doc("spoof_uid").set({
      uid: "spoof_uid",
      email: ADMIN_EMAIL,
      displayName: "Spoof",
      initializedAt: ts,
      updatedAt: ts,
    })
  );

  // Real verified owner email can initialize admin doc
  await assertSucceeds(
    adminDb().collection("admins").doc(ADMIN_UID).set({
      uid: ADMIN_UID,
      email: ADMIN_EMAIL,
      displayName: "Abir Owner",
      initializedAt: ts,
      updatedAt: ts,
    })
  );
});

test("User profiles: PII isolation, partial update, anti-escalation, admin suspension", async () => {
  await seedAdminDoc();
  const ts = nowPast();

  // Student cannot create profile with suspended=true or ghost field
  await assertFails(
    studentDb().collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      name: "Alice",
      email: ALICE_EMAIL,
      classLevel: 10,
      preferredLanguage: "bn",
      darkMode: false,
      leaderboardOptIn: true,
      suspended: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertFails(
    studentDb().collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      name: "Alice",
      email: ALICE_EMAIL,
      classLevel: 10,
      preferredLanguage: "bn",
      darkMode: false,
      leaderboardOptIn: true,
      suspended: false,
      isAdmin: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Valid Kotlin profile creation (omitting null photoUrl / fcmToken)
  await assertSucceeds(
    studentDb().collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      name: "Alice Rahman",
      email: ALICE_EMAIL,
      classLevel: 10,
      preferredLanguage: "bn",
      darkMode: false,
      leaderboardOptIn: true,
      suspended: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Student can update allowed preference fields
  await assertSucceeds(
    studentDb().collection("users").doc(ALICE_UID).update({
      classLevel: 11,
      darkMode: true,
      preferredLanguage: "en",
      updatedAt: nowPast(),
    })
  );

  // Student cannot self-unsuspend or mutate suspended/createdAt
  await assertFails(
    studentDb().collection("users").doc(ALICE_UID).update({
      suspended: true,
      updatedAt: nowPast(),
    })
  );

  // Bob cannot read Alice's PII or list users
  await assertFails(studentDb(BOB_UID, BOB_EMAIL).collection("users").doc(ALICE_UID).get());
  await assertFails(studentDb(BOB_UID, BOB_EMAIL).collection("users").get());

  // Admin can list users and suspend/unsuspend student
  await assertSucceeds(adminDb().collection("users").get());
  await assertSucceeds(
    adminDb().collection("users").doc(ALICE_UID).update({
      suspended: true,
      updatedAt: nowPast(),
    })
  );
});

test("Academic hierarchy: Admin CRUD, published filtering, student read/query alignment", async () => {
  await seedAdminDoc();
  const ts = nowPast();

  // Student cannot create class/subject/course/chapter/lesson
  await assertFails(
    studentDb().collection("classes").doc("class_10").set({
      level: 10,
      nameBn: "দশম শ্রেণি",
      nameEn: "Class 10",
      published: true,
      order: 10,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Admin creates published class 10 & unpublished class 11
  await assertSucceeds(
    adminDb().collection("classes").doc("class_10").set({
      level: 10,
      nameBn: "দশম শ্রেণি",
      nameEn: "Class 10",
      descriptionBn: "এসএসসি প্রস্তুতি",
      descriptionEn: "SSC Preparation",
      published: true,
      order: 10,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    adminDb().collection("classes").doc("class_11").set({
      level: 11,
      nameBn: "একাদশ শ্রেণি",
      nameEn: "Class 11",
      published: false,
      order: 11,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Student filtered published query succeeds; unfiltered query fails; reading draft fails
  await assertSucceeds(studentDb().collection("classes").where("published", "==", true).get());
  await assertFails(studentDb().collection("classes").get());
  await assertFails(studentDb().collection("classes").doc("class_11").get());

  // Admin creates subject, course, chapter, lesson
  await assertSucceeds(
    adminDb().collection("subjects").doc("sub_math_10").set({
      classLevel: 10,
      nameBn: "গণিত",
      nameEn: "Mathematics",
      iconName: "Calculate",
      colorHex: "#1565C0",
      published: true,
      order: 1,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    adminDb().collection("courses").doc("course_alg_10").set({
      classLevel: 10,
      subjectId: "sub_math_10",
      subjectNameBn: "গণিত",
      titleBn: "বীজগণিত সম্পূর্ণ কোর্স",
      titleEn: "Complete Algebra",
      instructorName: "Abir Sir",
      lessonCount: 1,
      published: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    adminDb().collection("chapters").doc("chap_1").set({
      courseId: "course_alg_10",
      classLevel: 10,
      titleBn: "অধ্যায় ১: বাস্তব সংখ্যা",
      titleEn: "Chapter 1: Real Numbers",
      order: 1,
      published: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    adminDb().collection("lessons").doc("lesson_1").set({
      courseId: "course_alg_10",
      chapterId: "chap_1",
      subjectId: "sub_math_10",
      classLevel: 10,
      titleBn: "মূলদ ও অমূলদ সংখ্যা",
      titleEn: "Rational & Irrational Numbers",
      contentBn: "বিস্তারিত নোট...",
      contentEn: "Detailed notes...",
      lessonType: "PDF",
      pdfUrl: "https://example.com/notes.pdf",
      durationMinutes: 15,
      order: 1,
      published: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Student filtered queries succeed
  await assertSucceeds(
    studentDb().collection("courses").where("published", "==", true).where("classLevel", "==", 10).get()
  );
  await assertSucceeds(
    studentDb().collection("lessons").where("published", "==", true).where("courseId", "==", "course_alg_10").get()
  );

  // Student future timestamp tamper fails
  await assertFails(
    adminDb().collection("lessons").doc("lesson_bad").set({
      courseId: "course_alg_10",
      chapterId: "chap_1",
      subjectId: "sub_math_10",
      classLevel: 10,
      titleBn: "Bad",
      titleEn: "Bad",
      contentBn: "Bad",
      contentEn: "Bad",
      lessonType: "TEXT",
      durationMinutes: 5,
      order: 2,
      published: true,
      createdAt: nowFuture(),
      updatedAt: nowFuture(),
    })
  );
});

test("Bookmarks and learning progress: strict per-user subcollection isolation", async () => {
  const ts = nowPast();
  await assertSucceeds(
    studentDb().collection("users").doc(ALICE_UID).collection("bookmarks").doc("lesson_1").set({
      lessonId: "lesson_1",
      courseId: "course_alg_10",
      subjectId: "sub_math_10",
      classLevel: 10,
      titleBn: "মূলদ সংখ্যা",
      titleEn: "Rational Numbers",
      lessonType: "TEXT",
      createdAt: ts,
    })
  );

  await assertSucceeds(
    studentDb().collection("users").doc(ALICE_UID).collection("progress").doc("lesson_1").set({
      lessonId: "lesson_1",
      courseId: "course_alg_10",
      subjectId: "sub_math_10",
      classLevel: 10,
      completed: true,
      progressPercent: 100,
      updatedAt: ts,
    })
  );

  await assertSucceeds(studentDb().collection("users").doc(ALICE_UID).collection("bookmarks").get());
  await assertFails(studentDb(BOB_UID, BOB_EMAIL).collection("users").doc(ALICE_UID).collection("bookmarks").get());
  await assertFails(studentDb(BOB_UID, BOB_EMAIL).collection("users").doc(ALICE_UID).collection("progress").get());
});

test("Exams, questions, attempts, and privacy-controlled leaderboard", async () => {
  await seedAdminDoc();
  const ts = nowPast();

  await assertSucceeds(
    adminDb().collection("exams").doc("exam_1").set({
      classLevel: 10,
      subjectId: "sub_math_10",
      subjectNameBn: "গণিত",
      titleBn: "মডেল টেস্ট ১",
      titleEn: "Model Test 1",
      durationMinutes: 20,
      totalMarks: 10.0,
      marksPerQuestion: 1.0,
      negativeMarkPerWrong: 0.25,
      questionCount: 1,
      published: true,
      resultsPublished: true,
      allowMultipleAttempts: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    adminDb().collection("exams").doc("exam_1").collection("questions").doc("q1").set({
      examId: "exam_1",
      examPublished: true,
      order: 1,
      questionBn: "২ + ২ = কত?",
      questionEn: "What is 2 + 2?",
      options: ["৩", "৪", "৫", "৬"],
      correctOptionIndex: 1,
      explanationBn: "২ এবং ২ যোগ করলে ৪ হয়।",
      explanationEn: "2 plus 2 equals 4.",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Student reads published exam questions with aligned filter
  await assertSucceeds(
    studentDb().collection("exams").doc("exam_1").collection("questions").where("examPublished", "==", true).get()
  );
  // Unfiltered questions list fails
  await assertFails(studentDb().collection("exams").doc("exam_1").collection("questions").get());

  // Student checking non-existent single-attempt doc before submitting succeeds
  const attemptId = `exam_1_${ALICE_UID}`;
  await assertSucceeds(studentDb().collection("exam_attempts").doc(attemptId).get());

  // Student submits single-attempt deterministic doc ID: exam_1_student_alice_123
  await assertSucceeds(
    studentDb().collection("exam_attempts").doc(attemptId).set({
      userId: ALICE_UID,
      studentDisplayName: "Alice Rahman",
      classLevel: 10,
      examId: "exam_1",
      examTitleBn: "মডেল টেস্ট ১",
      examTitleEn: "Model Test 1",
      selectedAnswers: { q1: 1 },
      score: 1.0,
      totalMarks: 10.0,
      correctCount: 1,
      wrongCount: 0,
      skippedCount: 0,
      timeTakenSeconds: 45,
      autoSubmitted: false,
      resultPublished: true,
      leaderboardVisible: true,
      submittedAt: ts,
    })
  );

  // Student cannot tamper with score after submission
  await assertFails(
    studentDb().collection("exam_attempts").doc(attemptId).update({
      score: 10.0,
    })
  );

  // Bob cannot read Alice's exam attempt
  await assertFails(studentDb(BOB_UID, BOB_EMAIL).collection("exam_attempts").doc(attemptId).get());

  // Alice can query her own exam attempts
  await assertSucceeds(
    studentDb().collection("exam_attempts").where("userId", "==", ALICE_UID).get()
  );

  // Privacy-controlled leaderboard: publicVisible=true vs false
  await assertSucceeds(
    studentDb().collection("leaderboard").doc(attemptId).set({
      examId: "exam_1",
      userId: ALICE_UID,
      displayName: "Alice Rahman",
      classLevel: 10,
      score: 1.0,
      totalMarks: 10.0,
      timeTakenSeconds: 45,
      publicVisible: true,
      updatedAt: ts,
    })
  );
  // Retake updating existing leaderboard entry succeeds for same student
  await assertSucceeds(
    studentDb().collection("leaderboard").doc(attemptId).set({
      examId: "exam_1",
      userId: ALICE_UID,
      displayName: "Alice Rahman",
      classLevel: 10,
      score: 2.0,
      totalMarks: 10.0,
      timeTakenSeconds: 40,
      publicVisible: true,
      updatedAt: nowPast(),
    })
  );
  await assertSucceeds(
    studentDb(BOB_UID, BOB_EMAIL).collection("leaderboard").where("examId", "==", "exam_1").where("publicVisible", "==", true).get()
  );
  await assertFails(
    studentDb(BOB_UID, BOB_EMAIL).collection("leaderboard").where("examId", "==", "exam_1").get()
  );

  // Alice hides her leaderboard entry; she can still query her own userId entries, Bob cannot
  await assertSucceeds(
    studentDb().collection("leaderboard").doc(attemptId).update({
      publicVisible: false,
      updatedAt: nowPast(),
    })
  );
  await assertSucceeds(
    studentDb().collection("leaderboard").where("userId", "==", ALICE_UID).get()
  );
  await assertFails(
    studentDb(BOB_UID, BOB_EMAIL).collection("leaderboard").where("userId", "==", ALICE_UID).get()
  );
});
